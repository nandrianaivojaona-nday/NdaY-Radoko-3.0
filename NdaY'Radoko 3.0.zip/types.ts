
export interface Activity {
  timestamp: string;
  event: string;
  details?: string;
}

export enum DroneStatus {
  Pending = "Pending Embarkation",
  InProgress = "PROM in Progress",
  Success = "PROM Successful",
  Failed = "PROM Failed",
  Active = "Active",
  Decommissioned = "Decommissioned",
  Diagnosing = "Diagnosing",
}

export enum PatientStatus {
  AwaitingDiagnosis = "Awaiting Diagnosis",
  DiagnosisInProgress = "Diagnosis In Progress",
  Diagnosed = "Diagnosed",
}

export type Language = 'en' | 'fr' | 'es' | 'de';
export type UserRole = 'Admin Global' | 'Field Officer';

export enum ProtocolStepStatus {
  Pending = "Pending Validation",
  Approved = "Approved",
  Rejected = "Rejected",
}

export interface ProtocolStep {
  id: number;
  originalText: string;
  aiAction: string;
  status: ProtocolStepStatus;
}

export interface Country {
  id: string;
  name: string;
  localLanguage: Language;
  youngInfantProtocol: string;
  childProtocol: string;
  isImplemented: boolean;
  youngInfantProtocolSteps?: ProtocolStep[];
  childProtocolSteps?: ProtocolStep[];
}

export type AgeProtocol = 'Young Infant' | 'Child';

export interface Drone {
  id:string;
  name: string;
  status: DroneStatus;
  accuracy: number | null;
  lastDiagnostic?: string;
  assignedPatientId?: string;
  activityLog: Activity[];
  countryId: string;
  ageProtocol: AgeProtocol | null;
  decommissionReason?: string;
  recommendedActions?: string;
}

export interface ChatMessage {
    role: 'user' | 'model' | 'system';
    text: string;
}

export interface Patient {
  id: string;
  name: string;
  age: string;
  symptoms: string[];
  status: PatientStatus;
  assignedDroneId: string | null;
  diagnosticReport: string | null;
  countryId: string;
  conversationHistory?: ChatMessage[];
}

export const LANGUAGES: { code: Language; name: string }[] = [
    { code: 'en', name: 'English' },
    { code: 'fr', name: 'Français' },
    { code: 'es', name: 'Español' },
    { code: 'de', name: 'Deutsch' },
];

// IMCI Implementation Plan Types
export enum TaskStatus {
  NotStarted = "Not Started",
  InProgress = "In Progress",
  Completed = "Completed",
}

export interface PlanActivity {
  description: string;
  expectedChanges: string;
  signsOfSuccess: string;
  dataGenerated: string;
  keyPersonnel: string;
  status: TaskStatus;
}

export interface PlanMilestone {
  description: string;
  activities: PlanActivity[];
}

export interface PlanDeliverables {
  frontend: string;
  backend: string;
}

export interface PlanQuarter {
  name: string;
  title: string;
  milestones: PlanMilestone[];
  deliverables?: PlanDeliverables;
}