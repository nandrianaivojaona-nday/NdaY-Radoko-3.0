
import React, { useState } from 'react';
import { useTranslations } from '../LanguageContext';
// FIX: Import INITIAL_IMPLEMENTATION_PLAN from constants with an alias, and PlanQuarter from types.
import { INITIAL_IMPLEMENTATION_PLAN as IMPLEMENTATION_PLAN } from '../constants';
import { PlanQuarter } from '../types';

interface ImplementationPlanModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

const AccordionIcon: React.FC<{ isOpen: boolean }> = ({ isOpen }) => (
    <svg className={`w-5 h-5 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
    </svg>
);

const QuarterSection: React.FC<{ quarter: PlanQuarter, isOpen: boolean, onToggle: () => void }> = ({ quarter, isOpen, onToggle }) => {
    const { t } = useTranslations();
    return (
        <div className="border-b border-brand-secondary/30">
            <button
                onClick={onToggle}
                className="w-full flex justify-between items-center p-4 text-left hover:bg-brand-surface"
            >
                <div>
                    <p className="text-xs font-semibold text-brand-primary uppercase tracking-wider">{t('quarter')} {quarter.name.split(' ')[1]}</p>
                    <h4 className="font-bold text-brand-text-primary mt-1">{quarter.title}</h4>
                </div>
                <AccordionIcon isOpen={isOpen} />
            </button>
            {isOpen && (
                <div className="p-4 bg-brand-background/30">
                    <div className="space-y-4">
                        {quarter.milestones.map((milestone, mIndex) => (
                            <div key={mIndex} className="pl-4 border-l-2 border-brand-secondary/50">
                                <h5 className="font-semibold text-brand-text-primary">{t('milestone')}: {milestone.description}</h5>
                                <ul className="mt-2 space-y-1 list-disc list-inside pl-4">
                                    {milestone.activities.map((activity, aIndex) => (
                                        <li key={aIndex} className="text-sm text-brand-text-secondary">
                                            <span className="font-medium text-brand-text-secondary/80">{t('activity')}:</span> {activity.description}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        ))}
                        {quarter.deliverables && (
                            <div className="pl-4 border-l-2 border-brand-primary/50 mt-4 pt-4 border-t border-brand-secondary/20">
                                <h5 className="font-bold text-brand-primary">{t('deliverables')}</h5>
                                <div className="mt-2 space-y-1 text-sm">
                                    <p><strong className="text-brand-text-secondary">{t('frontend')}:</strong> {quarter.deliverables.frontend}</p>
                                    <p><strong className="text-brand-text-secondary">{t('backend')}:</strong> {quarter.deliverables.backend}</p>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
};

const ImplementationPlanModal: React.FC<ImplementationPlanModalProps> = ({ isOpen, onClose, onConfirm }) => {
  const { t } = useTranslations();
  const [openQuarter, setOpenQuarter] = useState<string | null>(IMPLEMENTATION_PLAN[0]?.name || null);

  if (!isOpen) return null;

  const handleToggleQuarter = (quarterName: string) => {
    setOpenQuarter(prev => (prev === quarterName ? null : quarterName));
  };
  
  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-brand-surface rounded-lg shadow-xl w-full max-w-4xl m-4 border border-brand-secondary/50 flex flex-col max-h-[90vh]">
        <div className="p-6 border-b border-brand-secondary/30">
          <h2 className="text-2xl font-bold text-brand-text-primary">{t('implementationPlan')}</h2>
          <p className="text-sm text-brand-text-secondary mt-1">{t('implementationPlanDesc')}</p>
        </div>
        <div className="flex-grow overflow-y-auto">
           {IMPLEMENTATION_PLAN.map(quarter => (
               <QuarterSection 
                key={quarter.name}
                quarter={quarter}
                isOpen={openQuarter === quarter.name}
                onToggle={() => handleToggleQuarter(quarter.name)}
               />
           ))}
        </div>
        <div className="px-6 py-4 bg-brand-background/50 flex justify-end space-x-3 rounded-b-lg">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-brand-text-secondary/20 text-brand-text-primary rounded-md hover:bg-brand-text-secondary/40"
          >
            {t('cancel')}
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary"
          >
            {t('confirmAndImplement')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ImplementationPlanModal;
