
import React from 'react';
import { DroneStatus, PatientStatus } from '../types';

interface StatusBadgeProps {
  status: DroneStatus | PatientStatus;
}

const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  const statusConfig: Record<DroneStatus | PatientStatus, { color: string; dotColor: string; tooltip: string; }> = {
    // Drone Statuses
    [DroneStatus.Pending]: {
      color: 'bg-status-gray/20 text-status-gray',
      dotColor: 'bg-status-gray',
      tooltip: 'The drone is registered but has not yet been programmed with an IMCI protocol.',
    },
    [DroneStatus.InProgress]: {
      color: 'bg-status-blue/20 text-status-blue',
      dotColor: 'bg-status-blue animate-pulse-fast',
      tooltip: 'The drone is currently undergoing its core programming and protocol installation (PROM).',
    },
    [DroneStatus.Success]: {
      color: 'bg-status-green/20 text-status-green',
      dotColor: 'bg-status-green',
      tooltip: "The drone's PROM has been successfully installed. It is ready for self-diagnostics or assignment.",
    },
    [DroneStatus.Active]: {
      color: 'bg-brand-primary/20 text-brand-primary',
      dotColor: 'bg-brand-primary animate-pulse',
      tooltip: 'The drone is fully operational and ready to be assigned to a patient.',
    },
    [DroneStatus.Failed]: {
      color: 'bg-status-red/20 text-status-red',
      dotColor: 'bg-status-red',
      tooltip: "The drone's PROM installation failed. It requires maintenance.",
    },
    [DroneStatus.Decommissioned]: {
      color: 'bg-brand-text-secondary/20 text-brand-text-secondary',
      dotColor: 'bg-brand-text-secondary',
      tooltip: 'The drone has been retired from service.',
    },
    [DroneStatus.Diagnosing]: {
      color: 'bg-status-yellow/20 text-status-yellow',
      dotColor: 'bg-status-yellow animate-pulse-fast',
      tooltip: 'The drone is actively analyzing data for an assigned patient.',
    },

    // Patient Statuses
    [PatientStatus.AwaitingDiagnosis]: {
      color: 'bg-status-gray/20 text-status-gray',
      dotColor: 'bg-status-gray',
      tooltip: 'The patient is registered and waiting for a drone to be assigned for diagnosis.',
    },
    [PatientStatus.DiagnosisInProgress]: {
      color: 'bg-status-blue/20 text-status-blue',
      dotColor: 'bg-status-blue animate-pulse-fast',
      tooltip: 'A drone has been assigned and is currently performing a diagnostic analysis.',
    },
    [PatientStatus.Diagnosed]: {
      color: 'bg-status-green/20 text-status-green',
      dotColor: 'bg-status-green',
      tooltip: 'The diagnostic process is complete, and a report is available.',
    },
  };

  const config = statusConfig[status];

  if (!config) return null;

  return (
    <div
      className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium cursor-help ${config.color}`}
      title={config.tooltip}
    >
      <span className={`w-2.5 h-2.5 mr-2 rounded-full ${config.dotColor}`}></span>
      {status}
    </div>
  );
};

export default StatusBadge;
