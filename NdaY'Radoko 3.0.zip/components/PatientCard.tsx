
import React, { useState, useEffect } from 'react';
import { Patient, PatientStatus } from '../types';
import StatusBadge from './StatusBadge';
import { useTranslations } from '../LanguageContext';

interface PatientCardProps {
  patient: Patient;
  onAssignDrone: (patient: Patient) => void;
  onViewReport: (patient: Patient) => void;
}

const ActionButton: React.FC<{
  onClick: () => void;
  disabled?: boolean;
  children: React.ReactNode;
  className?: string;
}> = ({ onClick, disabled = false, children, className = '' }) => (
  <button
    onClick={onClick}
    disabled={disabled}
    className={`px-4 py-2 text-sm font-semibold rounded-md transition-all duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-brand-surface focus:ring-brand-primary disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
  >
    {children}
  </button>
);

// Diagnostic Phases for Patient Analysis
const DIAGNOSTIC_PHASES = [
  'Receiving patient data...',
  'Analyzing symptoms (ASK/OBSERVE)...',
  'Correlating with IMCI danger signs (ASSESS)...',
  'Determining illness severity (CLASSIFY)...',
  'Generating final report...',
];
const PHASE_DURATION = 800; // ms per phase

// Helper Icon components (reused from DiagnosticReportModal)
const CheckIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);
const SpinnerIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" {...props} className={`animate-spin ${props.className}`}>
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
);
const PendingIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);


const PatientCard: React.FC<PatientCardProps> = ({ patient, onAssignDrone, onViewReport }) => {
  const { t } = useTranslations();
  const [completedPhases, setCompletedPhases] = useState<number[]>([]);

  useEffect(() => {
      if (patient.status === PatientStatus.DiagnosisInProgress) {
          setCompletedPhases([]); // Reset on start
          const timeouts: number[] = [];
          DIAGNOSTIC_PHASES.forEach((_, index) => {
              const timeout = setTimeout(() => {
                  setCompletedPhases(prev => [...prev, index]);
              }, (index + 1) * PHASE_DURATION);
              timeouts.push(timeout as unknown as number);
          });
          return () => timeouts.forEach(clearTimeout);
      }
  }, [patient.status]);

  return (
    <div className="bg-brand-surface rounded-lg shadow-lg overflow-hidden border border-brand-secondary/30 transition-all duration-300 hover:shadow-brand-primary/20 hover:border-brand-primary/50">
      <div className="p-6">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm font-medium text-brand-primary">{patient.id}</p>
            <h3 className="text-xl font-bold text-brand-text-primary mt-1">{patient.name}</h3>
            <p className="text-sm text-brand-text-secondary">{patient.age} old</p>
          </div>
          <StatusBadge status={patient.status} />
        </div>

        <div className="mt-4">
          <p className="text-sm font-medium text-brand-text-secondary mb-2">{t('symptoms')}</p>
          <div className="flex flex-wrap gap-2">
            {patient.symptoms.map((symptom) => (
              <span key={symptom} className="px-2.5 py-1 text-xs font-semibold text-status-red bg-status-red/10 rounded-full">
                {symptom}
              </span>
            ))}
          </div>
        </div>
         {patient.status === PatientStatus.DiagnosisInProgress && (
            <div className="mt-6 p-4 bg-brand-background/30 rounded-lg">
                <h3 className="font-bold text-brand-text-primary mb-4 text-sm text-center">{t('aiDiagnosisInProgress')}</h3>
                <ul className="space-y-3">
                    {DIAGNOSTIC_PHASES.map((phase, index) => {
                    const isCompleted = completedPhases.includes(index);
                    const isInProgress = completedPhases.length === index;
                    return (
                        <li key={phase} className="flex items-center text-xs">
                        {isCompleted ? (
                            <CheckIcon className="w-4 h-4 text-status-green mr-2 flex-shrink-0" />
                        ) : isInProgress ? (
                            <SpinnerIcon className="w-4 h-4 text-brand-primary mr-2 flex-shrink-0" />
                        ) : (
                            <PendingIcon className="w-4 h-4 text-brand-text-secondary/50 mr-2 flex-shrink-0" />
                        )}
                        <span className={`transition-colors duration-300 ${isCompleted ? 'text-brand-text-secondary/80' : isInProgress ? 'text-brand-text-primary font-semibold' : 'text-brand-text-secondary/60'}`}>
                            {phase}
                        </span>
                        </li>
                    );
                    })}
                </ul>
            </div>
        )}
      </div>
       <div className="bg-brand-surface/50 px-6 py-4 flex items-center justify-end space-x-3">
        {patient.status === PatientStatus.AwaitingDiagnosis && (
          <ActionButton onClick={() => onAssignDrone(patient)} className="bg-brand-primary text-white hover:bg-brand-secondary">
            {t('assignDrone')}
          </ActionButton>
        )}
        {patient.status === PatientStatus.Diagnosed && (
          <ActionButton onClick={() => onViewReport(patient)} className="bg-status-green text-white hover:bg-green-600">
            {t('viewReport')}
          </ActionButton>
        )}
      </div>
    </div>
  );
};

export default PatientCard;
