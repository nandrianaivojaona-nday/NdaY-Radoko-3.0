
import React, { useState } from 'react';
import { useTranslations } from '../LanguageContext';

interface AddPatientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddPatient: (patientData: { name: string; age: string; symptoms: string[] }) => void;
}

const AddPatientModal: React.FC<AddPatientModalProps> = ({ isOpen, onClose, onAddPatient }) => {
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [symptoms, setSymptoms] = useState('');
  const { t } = useTranslations();

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && age.trim() && symptoms.trim()) {
      const symptomsArray = symptoms.split(',').map(s => s.trim()).filter(s => s);
      onAddPatient({ name: name.trim(), age: age.trim(), symptoms: symptomsArray });
      // Reset form and close
      setName('');
      setAge('');
      setSymptoms('');
      onClose();
    }
  };

  const isFormInvalid = !name.trim() || !age.trim() || !symptoms.trim();

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-brand-surface rounded-lg shadow-xl w-full max-w-md m-4 border border-brand-secondary/50">
        <div className="p-6 border-b border-brand-secondary/30">
          <h2 className="text-xl font-bold text-brand-text-primary">{t('registerNewPatient')}</h2>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-6 space-y-4">
            <div>
              <label htmlFor="patient-name" className="block text-sm font-medium text-brand-text-secondary mb-2">
                {t('patientName')}
              </label>
              <input
                id="patient-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Baby Fatima"
                className="w-full bg-brand-background border border-brand-secondary/50 rounded-md px-3 py-2 text-brand-text-primary focus:outline-none focus:ring-2 focus:ring-brand-primary"
                required
              />
            </div>
             <div>
              <label htmlFor="patient-age" className="block text-sm font-medium text-brand-text-secondary mb-2">
                {t('patientAge')}
              </label>
              <input
                id="patient-age"
                type="text"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                placeholder="e.g., 2 months"
                className="w-full bg-brand-background border border-brand-secondary/50 rounded-md px-3 py-2 text-brand-text-primary focus:outline-none focus:ring-2 focus:ring-brand-primary"
                required
              />
            </div>
             <div>
              <label htmlFor="patient-symptoms" className="block text-sm font-medium text-brand-text-secondary mb-2">
                {t('patientSymptoms')}
              </label>
              <textarea
                id="patient-symptoms"
                value={symptoms}
                onChange={(e) => setSymptoms(e.target.value)}
                placeholder="e.g., fever, poor feeding, cough"
                className="w-full bg-brand-background border border-brand-secondary/50 rounded-md px-3 py-2 text-brand-text-primary focus:outline-none focus:ring-2 focus:ring-brand-primary"
                rows={3}
                required
              />
            </div>
          </div>
          <div className="px-6 py-4 bg-brand-background/50 flex justify-end space-x-3 rounded-b-lg">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-brand-text-secondary/20 text-brand-text-primary rounded-md hover:bg-brand-text-secondary/40"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              disabled={isFormInvalid}
              className="px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary disabled:opacity-50"
            >
              {t('savePatient')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddPatientModal;
