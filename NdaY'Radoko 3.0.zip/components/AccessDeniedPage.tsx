import React from 'react';
import { useTranslations } from '../LanguageContext';

interface AccessDeniedPageProps {
    onGoHome: () => void;
}

const AccessDeniedPage: React.FC<AccessDeniedPageProps> = ({ onGoHome }) => {
    const { t } = useTranslations();
    return (
        <div className="flex flex-col items-center justify-center h-full text-center p-8 bg-brand-surface/50 rounded-lg border-2 border-dashed border-brand-secondary/30">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-status-red mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
            <h2 className="text-2xl font-bold text-brand-text-primary">{t('accessDeniedTitle')}</h2>
            <p className="mt-2 max-w-md text-brand-text-secondary">{t('accessDeniedMessage')}</p>
            <button onClick={onGoHome} className="mt-6 px-4 py-2 bg-brand-primary text-white font-semibold rounded-lg shadow-md hover:bg-brand-secondary transition-colors duration-300">
                {t('goHome')}
            </button>
        </div>
    );
};

export default AccessDeniedPage;
