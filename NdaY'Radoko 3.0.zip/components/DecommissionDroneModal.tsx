import React, { useState, useEffect } from 'react';
import { Drone } from '../types';
import { useTranslations } from '../LanguageContext';

interface DecommissionDroneModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (id: string, reason: string, actions: string) => void;
  drone: Drone | null;
}

const DecommissionDroneModal: React.FC<DecommissionDroneModalProps> = ({ isOpen, onClose, onConfirm, drone }) => {
    const { t } = useTranslations();
    const [reason, setReason] = useState('');
    const [actions, setActions] = useState('');

    useEffect(() => {
        if (!isOpen) {
            setReason('');
            setActions('');
        }
    }, [isOpen]);

    if (!isOpen || !drone) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (reason) {
            onConfirm(drone.id, reason, actions);
        }
    };

    const reasons = [
        t('hardwareMalfunction'),
        t('routineMaintenance'),
        t('damagedInField'),
        t('softwareFailure'),
        t('other')
    ];

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-brand-surface rounded-lg shadow-xl w-full max-w-md m-4 border border-brand-secondary/50">
                <form onSubmit={handleSubmit}>
                    <div className="p-6 border-b border-brand-secondary/30">
                        <h2 className="text-xl font-bold text-brand-text-primary">{t('decommissionDrone')}: <span className="text-brand-primary">{drone.name}</span></h2>
                    </div>
                    <div className="p-6 space-y-4">
                        <div>
                            <label htmlFor="decommission-reason" className="block text-sm font-medium text-brand-text-secondary mb-2">{t('reasonForDecommissioning')}</label>
                            <select id="decommission-reason" value={reason} onChange={e => setReason(e.target.value)} required className="w-full bg-brand-background border border-brand-secondary/50 rounded-md px-3 py-2 text-brand-text-primary focus:outline-none focus:ring-2 focus:ring-brand-primary">
                                <option value="" disabled>{t('selectReason')}</option>
                                {reasons.map(r => <option key={r} value={r}>{r}</option>)}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="recommission-actions" className="block text-sm font-medium text-brand-text-secondary mb-2">{t('recommissioningActions')}</label>
                            <textarea id="recommission-actions" value={actions} onChange={e => setActions(e.target.value)} rows={3} className="w-full bg-brand-background border border-brand-secondary/50 rounded-md px-3 py-2 text-brand-text-primary focus:outline-none focus:ring-2 focus:ring-brand-primary" placeholder={t('recommissioningActionsPlaceholder')} />
                        </div>
                    </div>
                    <div className="px-6 py-4 bg-brand-background/50 flex justify-end space-x-3 rounded-b-lg">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-brand-text-secondary/20 text-brand-text-primary rounded-md hover:bg-brand-text-secondary/40">{t('cancel')}</button>
                        <button type="submit" disabled={!reason} className="px-4 py-2 bg-status-red text-white rounded-md hover:bg-red-700 disabled:opacity-50">{t('confirmDecommission')}</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default DecommissionDroneModal;
