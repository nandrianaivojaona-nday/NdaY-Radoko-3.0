import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Drone, Patient, Country, ChatMessage } from '../types';
import { useTranslations } from '../LanguageContext';
import { getImciChatResponse } from '../services/geminiService';

interface LiveDiagnosisModalProps {
  isOpen: boolean;
  onConclude: (conversationHistory: ChatMessage[]) => void;
  drone: Drone;
  patient: Patient;
  country: Country;
}

const VISUAL_CHECK_TAG = '[VISUAL_CHECK]';

// @ts-ignore
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

const blobToBase64 = (blob: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            const base64data = reader.result as string;
            resolve(base64data.split(',')[1]);
        };
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
};

const LiveDiagnosisModal: React.FC<LiveDiagnosisModalProps> = ({ isOpen, onConclude, drone, patient, country }) => {
  const { t, language } = useTranslations();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const recognitionRef = useRef<any>(null);

  const [transcript, setTranscript] = useState<ChatMessage[]>([]);
  const [isListening, setIsListening] = useState(false);
  const [isAISpeaking, setIsAISpeaking] = useState(false);
  const [isAwaitingResponse, setIsAwaitingResponse] = useState(false);
  const [userInput, setUserInput] = useState('');
  const [error, setError] = useState<string | null>(null);

  const [isVisualCheckMode, setIsVisualCheckMode] = useState(false);
  const [isAnalyzingImage, setIsAnalyzingImage] = useState(false);
  const transcriptEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    transcriptEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [transcript, isAwaitingResponse, isAnalyzingImage]);


  const speak = useCallback((text: string) => {
    return new Promise<void>((resolve) => {
        setIsAISpeaking(true);
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = language;
        utterance.onend = () => {
            setIsAISpeaking(false);
            resolve();
        };
        window.speechSynthesis.speak(utterance);
    });
  }, [language]);
  
  const processAiResponse = useCallback(async (aiResponseText: string) => {
      let processedText = aiResponseText;
      let needsVisualCheck = false;

      if (aiResponseText.includes(VISUAL_CHECK_TAG)) {
          processedText = aiResponseText.replace(VISUAL_CHECK_TAG, '').trim();
          needsVisualCheck = true;
      }
      
      const aiMessage: ChatMessage = { role: 'model', text: processedText };
      setTranscript(prev => [...prev, aiMessage]);
      await speak(processedText);

      if (needsVisualCheck) {
          setIsVisualCheckMode(true);
      }
      setIsAwaitingResponse(false);

  }, [speak]);

  const processUserResponse = useCallback(async (text: string, image: { data: string, mimeType: string } | null = null) => {
      const userMessage: ChatMessage = { role: 'user', text };
      setTranscript(prev => [...prev, userMessage]);
      setIsAwaitingResponse(true);
      setUserInput('');

      const ageProtocolType = drone.ageProtocol === 'Young Infant' ? 'youngInfantProtocol' : 'childProtocol';
      const protocol = country[ageProtocolType];
      
      const aiResponseText = await getImciChatResponse(
          [...transcript, userMessage], 
          text, 
          image, 
          language, 
          protocol
      );
      
      await processAiResponse(aiResponseText);

  }, [transcript, drone.ageProtocol, country, language, processAiResponse]);


  const handleCaptureImage = useCallback(async () => {
    if (!videoRef.current || !canvasRef.current) return;

    setIsVisualCheckMode(false);
    setIsAnalyzingImage(true);

    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d')?.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
    
    canvas.toBlob(async (blob) => {
        if (blob) {
            const base64Data = await blobToBase64(blob);
            await processUserResponse("Here is the image you requested for analysis.", { data: base64Data, mimeType: 'image/jpeg' });
        }
        setIsAnalyzingImage(false);
    }, 'image/jpeg');

  }, [processUserResponse]);


  useEffect(() => {
    if (isOpen) {
      // Setup camera
      navigator.mediaDevices.getUserMedia({ video: true })
        .then(stream => {
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
        })
        .catch(() => setError(t('cameraError')));
      
      // Setup speech recognition
      if (SpeechRecognition) {
        recognitionRef.current = new SpeechRecognition();
        recognitionRef.current.continuous = false;
        recognitionRef.current.interimResults = false;
        recognitionRef.current.lang = language;
        recognitionRef.current.onresult = (event: any) => {
            const spokenText = event.results[0][0].transcript;
            processUserResponse(spokenText);
            setIsListening(false);
        };
        recognitionRef.current.onerror = (event: any) => {
            console.error('Speech recognition error', event.error);
            setIsListening(false);
        };
      } else {
        setError(t('micError'));
      }

      // Initial AI message
      const initialSymptoms = patient.symptoms.join(', ');
      const introText = `Hello, I am ${drone.name}. I am beginning a diagnostic session for ${patient.name}. The initial symptoms reported are: ${initialSymptoms}. Can you please describe the child's condition in your own words?`;
      
      const startConversation = async () => {
        const aiResponseText = await getImciChatResponse([], introText, null, language, country.youngInfantProtocol);
        await processAiResponse(aiResponseText);
      };

      startConversation();

      return () => { // Cleanup
        const stream = videoRef.current?.srcObject as MediaStream;
        stream?.getTracks().forEach(track => track.stop());
        window.speechSynthesis.cancel();
        recognitionRef.current?.abort();
        setTranscript([]);
        setIsVisualCheckMode(false);
        setIsAnalyzingImage(false);
        setError(null);
      };
    }
  }, [isOpen, drone.name, patient.name, patient.symptoms, language, t, processUserResponse, processAiResponse, country.youngInfantProtocol]);
  
  const handleToggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      recognitionRef.current?.start();
      setIsListening(true);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-brand-surface rounded-lg shadow-xl w-full h-full max-w-6xl border border-brand-secondary/50 flex flex-col">
        <div className="p-4 border-b border-brand-secondary/30">
          <h2 className="text-xl font-bold text-brand-text-primary">{t('liveDiagnosis')}</h2>
          <p className="text-sm text-brand-text-secondary">
            {drone.name} / {patient.name} ({patient.age})
          </p>
        </div>

        <div className="flex-grow grid grid-cols-1 md:grid-cols-2 gap-4 p-4 overflow-hidden">
          {/* Left Panel: Camera */}
          <div className="flex flex-col bg-brand-background/50 rounded-lg p-3">
            <h3 className="font-bold text-brand-text-primary mb-2">{t('droneCameraFeed')}</h3>
            <div className="relative flex-grow bg-black rounded flex items-center justify-center">
              {error ? (
                <p className="text-status-red">{error}</p>
              ) : (
                <>
                    <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover rounded"></video>
                    <canvas ref={canvasRef} className="hidden"></canvas>
                    {(isVisualCheckMode || isAnalyzingImage) && (
                        <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center">
                           {isAnalyzingImage ? (
                                <>
                                    <svg className="animate-spin h-10 w-10 text-brand-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                    </svg>
                                    <p className="mt-4 font-semibold text-brand-primary animate-pulse">{t('aiAnalyzing')}</p>
                                </>
                           ) : (
                               <>
                                <p className="font-semibold text-white mb-4">{t('positionInfant')}</p>
                                <button onClick={handleCaptureImage} className="px-6 py-3 bg-brand-primary text-white font-bold rounded-lg shadow-lg hover:bg-brand-secondary transition-colors">
                                    {t('captureForAI')}
                                </button>
                               </>
                           )}
                        </div>
                    )}
                </>
              )}
            </div>
          </div>

          {/* Right Panel: Interaction */}
          <div className="flex flex-col bg-brand-background/50 rounded-lg overflow-hidden">
            <h3 className="font-bold text-brand-text-primary p-3 border-b border-brand-secondary/30">{t('interactionTranscript')}</h3>
            <div className="flex-grow p-3 space-y-4 overflow-y-auto">
              {transcript.map((msg, index) => (
                <div key={index} className={`flex items-start gap-2.5 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                  <div className={`flex flex-col w-full max-w-xs p-3 border-gray-200 rounded-lg ${msg.role === 'user' ? 'bg-brand-primary' : 'bg-brand-secondary'}`}>
                    <div className="flex items-center space-x-2 rtl:space-x-reverse">
                        <span className="text-sm font-semibold text-white">{msg.role === 'user' ? 'You' : t('aiAssistant')}</span>
                    </div>
                    <p className="text-sm font-normal py-2 text-white whitespace-pre-wrap">{msg.text}</p>
                  </div>
                </div>
              ))}
              {isAwaitingResponse && !isAnalyzingImage && (
                <div className="flex items-start gap-2.5">
                    <div className="flex flex-col w-full max-w-xs p-3 border-gray-200 rounded-lg bg-brand-secondary">
                        <p className="text-sm font-normal py-2 text-white italic animate-pulse">{t('awaitingResponse')}</p>
                    </div>
                </div>
              )}
              <div ref={transcriptEndRef} />
            </div>
            
            <div className="p-3 border-t border-brand-secondary/30">
                 <div className="flex items-center gap-2">
                    <button onClick={handleToggleListening} disabled={isAISpeaking || isAwaitingResponse || !SpeechRecognition || isVisualCheckMode} className="p-3 bg-brand-primary rounded-full text-white disabled:opacity-50 disabled:bg-brand-secondary">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                        </svg>
                    </button>
                    <input 
                        type="text" 
                        value={isListening ? t('listening') : userInput}
                        onChange={(e) => setUserInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && userInput && processUserResponse(userInput)}
                        placeholder={t('yourResponse')}
                        className="flex-grow bg-brand-background border border-brand-secondary/50 rounded-md px-3 py-2 text-brand-text-primary focus:outline-none focus:ring-2 focus:ring-brand-primary"
                        disabled={isListening || isAISpeaking || isAwaitingResponse || isVisualCheckMode}
                    />
                 </div>
            </div>
          </div>
        </div>
        
        <div className="px-4 py-3 bg-brand-background/50 flex justify-end rounded-b-lg">
          <button
            onClick={() => onConclude(transcript)}
            className="px-4 py-2 bg-status-green text-white font-semibold rounded-md hover:bg-green-600 disabled:opacity-50"
            disabled={isAISpeaking || isAwaitingResponse || isListening || isVisualCheckMode}
          >
            {t('endSessionAndReport')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default LiveDiagnosisModal;
