
import React, { useState } from 'react';
import { generateDroneName } from '../services/geminiService';
import { useTranslations } from '../LanguageContext';

interface AddDroneModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddDrone: (name: string) => void;
}

const AddDroneModal: React.FC<AddDroneModalProps> = ({ isOpen, onClose, onAddDrone }) => {
  const [name, setName] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const { t } = useTranslations();

  if (!isOpen) return null;

  const handleGenerateName = async () => {
    setIsGenerating(true);
    const generatedName = await generateDroneName();
    setName(generatedName);
    setIsGenerating(false);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onAddDrone(name.trim());
      setName('');
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-brand-surface rounded-lg shadow-xl w-full max-w-md m-4 border border-brand-secondary/50">
        <div className="p-6 border-b border-brand-secondary/30">
          <h2 className="text-xl font-bold text-brand-text-primary">{t('registerNewDrone')}</h2>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-6">
            <label htmlFor="drone-name" className="block text-sm font-medium text-brand-text-secondary mb-2">
              {t('droneName')}
            </label>
            <div className="flex space-x-2">
              <input
                id="drone-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Nightingale-8"
                className="flex-grow bg-brand-background border border-brand-secondary/50 rounded-md px-3 py-2 text-brand-text-primary focus:outline-none focus:ring-2 focus:ring-brand-primary"
                required
              />
              <button
                type="button"
                onClick={handleGenerateName}
                disabled={isGenerating}
                className="px-4 py-2 bg-brand-secondary text-white rounded-md hover:bg-brand-primary disabled:opacity-50 flex items-center justify-center"
              >
                {isGenerating ? (
                  <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M5 4a1 1 0 00-2 0v7.268a2 2 0 000 3.464V16a1 1 0 102 0v-1.268a2 2 0 000-3.464V4zM11 4a1 1 0 10-2 0v1.268a2 2 0 000 3.464V16a1 1 0 102 0V8.732a2 2 0 000-3.464V4zM16 3a1 1 0 011 1v7.268a2 2 0 010 3.464V16a1 1 0 11-2 0v-1.268a2 2 0 010-3.464V4a1 1 0 011-1z" />
                  </svg>
                )}
              </button>
            </div>
          </div>
          <div className="px-6 py-4 bg-brand-background/50 flex justify-end space-x-3 rounded-b-lg">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-brand-text-secondary/20 text-brand-text-primary rounded-md hover:bg-brand-text-secondary/40"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary"
            >
              {t('addDrone')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddDroneModal;
