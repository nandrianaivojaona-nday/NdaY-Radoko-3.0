import React from 'react';
import { useTranslations } from '../LanguageContext';
import LanguageSwitcher from './LanguageSwitcher';
import { Country, UserRole } from '../types';

export type Page = 'home' | 'patients' | 'drones' | 'admin';

interface NavbarProps {
    currentPage: Page;
    setCurrentPage: (page: Page) => void;
    countries: Country[];
    activeCountryId: string | null;
    onSelectCountry: (countryId: string | null) => void;
    currentUserRole: UserRole;
    setCurrentUserRole: (role: UserRole) => void;
}

const NavItem: React.FC<{
    page: Page;
    label: string;
    icon: React.ReactElement;
    currentPage: Page;
    setCurrentPage: (page: Page) => void;
}> = ({ page, label, icon, currentPage, setCurrentPage }) => {
    const isActive = currentPage === page;
    return (
        <li>
            <a
                href="#"
                onClick={(e) => { e.preventDefault(); setCurrentPage(page); }}
                className={`flex items-center p-3 rounded-lg transition-colors duration-200 ${isActive ? 'bg-brand-primary/20 text-brand-primary' : 'text-brand-text-secondary hover:bg-brand-surface hover:text-brand-text-primary'}`}
            >
                {React.cloneElement(icon, { className: "w-6 h-6 mr-3" })}
                <span className="font-semibold">{label}</span>
            </a>
        </li>
    );
};


const Navbar: React.FC<NavbarProps> = ({ currentPage, setCurrentPage, countries, activeCountryId, onSelectCountry, currentUserRole, setCurrentUserRole }) => {
    const { t } = useTranslations();

    return (
        <nav className="w-64 bg-brand-surface/50 backdrop-blur-sm border-r border-brand-secondary/30 flex flex-col p-4 shrink-0">
            <div className="flex items-center mb-6 p-3">
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-brand-primary mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 2L2 7l10 5 10-5-10-5z" />
                    <path d="M2 17l10 5 10-5" />
                    <path d="M2 12l10 5 10-5" />
                </svg>
                <h1 className="text-xl font-bold text-brand-text-primary leading-tight">
                    NdaY' Radoko
                </h1>
            </div>
            
            <div className="px-1 mb-4">
                <label className="block text-xs font-medium text-brand-text-secondary mb-2 px-1">{t('country')}</label>
                <select
                    value={activeCountryId || ''}
                    onChange={(e) => onSelectCountry(e.target.value || null)}
                    className="w-full appearance-none bg-brand-surface border border-brand-secondary/50 rounded-md py-2.5 pl-3 pr-8 text-sm font-semibold text-brand-text-primary focus:outline-none focus:ring-2 focus:ring-brand-primary"
                >
                    <option value="">{t('selectCountry')}</option>
                    {countries.map(country => (
                        <option key={country.id} value={country.id}>
                            {country.name} {!country.isImplemented ? `(${t('notImplemented')})` : ''}
                        </option>
                    ))}
                </select>
            </div>
            
            <div className="px-1 mb-4">
                <label className="block text-xs font-medium text-brand-text-secondary mb-2 px-1">{t('localLanguage')}</label>
                <LanguageSwitcher />
            </div>

            <div className="px-1 mb-8">
                <label className="block text-xs font-medium text-brand-text-secondary mb-2 px-1">{t('userRole')}</label>
                <select
                    value={currentUserRole}
                    onChange={(e) => setCurrentUserRole(e.target.value as UserRole)}
                    className="w-full appearance-none bg-brand-surface border border-brand-secondary/50 rounded-md py-2.5 pl-3 pr-8 text-sm font-semibold text-brand-text-primary focus:outline-none focus:ring-2 focus:ring-brand-primary"
                >
                    <option value="Field Officer">{t('fieldOfficer')}</option>
                    <option value="Admin Global">{t('adminGlobal')}</option>
                </select>
            </div>

            <ul className="space-y-2">
                <NavItem page="home" label={t('home')} icon={<HomeIcon />} currentPage={currentPage} setCurrentPage={setCurrentPage} />
                <NavItem page="patients" label={t('patients')} icon={<UsersIcon />} currentPage={currentPage} setCurrentPage={setCurrentPage} />
                <NavItem page="drones" label={t('drones')} icon={<ChipIcon />} currentPage={currentPage} setCurrentPage={setCurrentPage} />
                {currentUserRole === 'Admin Global' && (
                  <NavItem page="admin" label={t('adminConsole')} icon={<CogIcon />} currentPage={currentPage} setCurrentPage={setCurrentPage} />
                )}
            </ul>

            <div className="mt-auto pt-4 border-t border-brand-secondary/20">
              {/* This space is now intentionally left blank, but keeps the border for styling */}
            </div>
        </nav>
    );
};

// SVG Icons
const HomeIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
  </svg>
);
const UsersIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21a6 6 0 00-9-5.197M15 21a6 6 0 00-9-5.197" />
  </svg>
);
const ChipIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M12 6V3m0 18v-3M5.636 5.636L4.222 4.222m15.556 15.556L18.364 18.364M18.364 5.636L19.778 4.222m-15.556 15.556L5.636 18.364M12 16a4 4 0 100-8 4 4 0 000 8z" />
  </svg>
);
const CogIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);

export default Navbar;