
import React from 'react';
import { Drone } from '../types';
import { useTranslations } from '../LanguageContext';

interface ActivityLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  drone: Drone | null;
}

const ActivityLogModal: React.FC<ActivityLogModalProps> = ({ isOpen, onClose, drone }) => {
  const { t } = useTranslations();

  if (!isOpen || !drone) return null;

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString(undefined, {
      dateStyle: 'medium',
      timeStyle: 'short',
    });
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-brand-surface rounded-lg shadow-xl w-full max-w-2xl m-4 border border-brand-secondary/50 flex flex-col max-h-[90vh]">
        <div className="p-6 border-b border-brand-secondary/30">
          <h2 className="text-xl font-bold text-brand-text-primary">{t('activityLog')}: <span className="text-brand-primary">{drone.name}</span></h2>
          <p className="text-sm text-brand-text-secondary mt-1">{drone.id}</p>
        </div>
        <div className="p-6 overflow-y-auto flex-grow">
          {drone.activityLog && drone.activityLog.length > 0 ? (
            <ul className="space-y-4">
              {drone.activityLog.map((activity, index) => (
                <li key={index} className="flex items-start space-x-4">
                  <div className="flex-shrink-0 flex flex-col items-center">
                     <div className="w-6 h-6 bg-brand-primary/20 rounded-full flex items-center justify-center">
                       <div className="w-2.5 h-2.5 bg-brand-primary rounded-full"></div>
                     </div>
                     {index < drone.activityLog.length - 1 && <div className="w-0.5 h-12 bg-brand-secondary/30 mt-1"></div>}
                  </div>
                  <div>
                    <p className="font-semibold text-brand-text-primary">{activity.event}</p>
                    <p className="text-sm text-brand-text-secondary">{formatTimestamp(activity.timestamp)}</p>
                    {activity.details && (
                      <p className="text-xs text-brand-text-secondary/80 mt-1">{activity.details}</p>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <div className="text-center py-10">
              <p className="text-brand-text-secondary">{t('noActivityLogged')}</p>
            </div>
          )}
        </div>
        <div className="px-6 py-4 bg-brand-background/50 flex justify-end rounded-b-lg">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary"
          >
            {t('close')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ActivityLogModal;
