
import React, { useState, useEffect, useCallback } from 'react';
import { Country, AgeProtocol, ProtocolStep, ProtocolStepStatus } from '../types';
import { useTranslations } from '../LanguageContext';
import { parseProtocolIntoSteps, generateAiActionForStep } from '../services/geminiService';

interface PromTrainingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (countryId: string, protocolType: AgeProtocol, steps: ProtocolStep[]) => void;
  country: Country | null;
}

const LoadingSpinner: React.FC = () => (
    <div className="flex items-center justify-center h-full">
        <div className="flex flex-col items-center">
             <svg className="animate-spin h-8 w-8 text-brand-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <p className="mt-3 text-brand-text-secondary text-sm font-semibold">Loading AI Actions...</p>
        </div>
    </div>
);

const ErrorDisplay: React.FC<{ message: string }> = ({ message }) => (
    <div className="flex items-center justify-center h-full p-4 bg-status-red/10 rounded-lg">
        <p className="text-status-red font-semibold text-center">{message}</p>
    </div>
);

const PromTrainingModal: React.FC<PromTrainingModalProps> = ({ isOpen, onClose, onSave, country }) => {
  const { t, language } = useTranslations();
  const [selectedProtocol, setSelectedProtocol] = useState<AgeProtocol>('Young Infant');
  const [steps, setSteps] = useState<ProtocolStep[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const processProtocol = useCallback(async () => {
    if (!country) return;

    const protocolText = selectedProtocol === 'Young Infant' 
        ? country.youngInfantProtocol 
        : country.childProtocol;

    if (!protocolText || protocolText.startsWith('Default')) {
        setError(`No detailed protocol available for ${selectedProtocol}. Please add it in the Admin Console.`);
        setSteps([]);
        return;
    }
    
    setIsLoading(true);
    setError(null);

    try {
        const parsedStepsText = await parseProtocolIntoSteps(protocolText);
        const initialSteps: ProtocolStep[] = parsedStepsText.map((text, index) => ({
            id: index,
            originalText: text,
            aiAction: '',
            status: ProtocolStepStatus.Pending
        }));
        setSteps(initialSteps);

        // Sequentially generate AI actions
        for (let i = 0; i < initialSteps.length; i++) {
            const aiAction = await generateAiActionForStep(initialSteps[i].originalText, language);
            setSteps(prev => prev.map(step => step.id === i ? { ...step, aiAction } : step));
        }

    } catch (e: any) {
        setError(e.message || t('protocolParseError'));
    } finally {
        setIsLoading(false);
    }
  }, [country, selectedProtocol, language, t]);


  useEffect(() => {
    if (isOpen && country) {
      processProtocol();
    }
  }, [isOpen, country, selectedProtocol, processProtocol]);

  const handleUpdateStepStatus = (id: number, status: ProtocolStepStatus) => {
    setSteps(prev => prev.map(step => step.id === id ? { ...step, status } : step));
  };

  const handleSave = () => {
    if (country) {
        onSave(country.id, selectedProtocol, steps);
    }
  };
  
  const getStatusClasses = (status: ProtocolStepStatus) => {
    switch (status) {
        case ProtocolStepStatus.Approved: return "border-l-4 border-status-green bg-status-green/10";
        case ProtocolStepStatus.Rejected: return "border-l-4 border-status-red bg-status-red/10";
        default: return "border-l-4 border-brand-secondary/50";
    }
  }

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-brand-surface rounded-lg shadow-xl w-full max-w-4xl border border-brand-secondary/50 flex flex-col max-h-[90vh]">
        <div className="p-6 border-b border-brand-secondary/30">
          <h2 className="text-2xl font-bold text-brand-text-primary">{t('promTraining')} for <span className="text-brand-primary">{country?.name}</span></h2>
          <p className="text-sm text-brand-text-secondary mt-1">{t('promTrainingDescription')}</p>
        </div>
        
        <div className="p-4 bg-brand-background/30 border-b border-brand-secondary/30">
             <div className="flex items-center gap-4">
                <span className="text-sm font-semibold text-brand-text-secondary">{t('ageProtocol')}:</span>
                <div className="flex gap-2 rounded-lg bg-brand-surface p-1">
                    {(['Young Infant', 'Child'] as AgeProtocol[]).map(p => (
                        <button key={p} onClick={() => setSelectedProtocol(p)} className={`px-3 py-1 text-sm font-semibold rounded-md ${selectedProtocol === p ? 'bg-brand-primary text-white' : 'text-brand-text-secondary hover:bg-brand-surface/50'}`}>
                            {t(p === 'Young Infant' ? 'youngInfant' : 'child')}
                        </button>
                    ))}
                </div>
            </div>
        </div>

        <div className="flex-grow overflow-y-auto p-6">
            {isLoading ? <LoadingSpinner /> : error ? <ErrorDisplay message={error} /> : (
                <div className="space-y-4">
                    {steps.map(step => (
                        <div key={step.id} className={`p-4 rounded-lg transition-colors duration-200 ${getStatusClasses(step.status)}`}>
                            <p className="text-xs font-bold text-brand-text-secondary uppercase tracking-wider">{t('step')} {step.id + 1}</p>
                            <div className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <p className="text-sm font-semibold text-brand-text-primary mb-1">{t('originalProtocolText')}</p>
                                    <p className="text-sm text-brand-text-secondary bg-brand-background/50 p-2 rounded-md">{step.originalText}</p>
                                </div>
                                 <div>
                                    <p className="text-sm font-semibold text-brand-text-primary mb-1">{t('aiGeneratedAction')}</p>
                                    {step.aiAction ? 
                                        <p className="text-sm text-brand-primary bg-brand-primary/10 p-2 rounded-md italic">"{step.aiAction}"</p>
                                        : <div className="h-8 w-2/3 bg-brand-background/50 rounded-md animate-pulse"></div>
                                    }
                                </div>
                            </div>
                            <div className="mt-3 flex items-center justify-end gap-2">
                                <button onClick={() => handleUpdateStepStatus(step.id, ProtocolStepStatus.Rejected)} className={`px-3 py-1 text-xs font-semibold rounded-md ${step.status === ProtocolStepStatus.Rejected ? 'bg-status-red text-white' : 'bg-status-red/20 text-status-red hover:bg-status-red/40'}`}>
                                    {t('reject')}
                                </button>
                                <button onClick={() => handleUpdateStepStatus(step.id, ProtocolStepStatus.Approved)} className={`px-3 py-1 text-xs font-semibold rounded-md ${step.status === ProtocolStepStatus.Approved ? 'bg-status-green text-white' : 'bg-status-green/20 text-status-green hover:bg-status-green/40'}`}>
                                    {t('approve')}
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>

        <div className="px-6 py-4 bg-brand-background/50 flex justify-end space-x-3 rounded-b-lg border-t border-brand-secondary/30">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-brand-text-secondary/20 text-brand-text-primary rounded-md hover:bg-brand-text-secondary/40"
          >
            {t('cancel')}
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={isLoading || steps.some(s => s.status === ProtocolStepStatus.Pending)}
            className="px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary disabled:opacity-50"
          >
            {t('saveAndProgramDrone')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default PromTrainingModal;