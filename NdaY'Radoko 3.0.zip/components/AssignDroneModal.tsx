
import React, { useState } from 'react';
import { Drone, Patient } from '../types';
import { useTranslations } from '../LanguageContext';

interface AssignDroneModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAssign: (droneId: string) => void;
  patient: Patient | null;
  availableDrones: Drone[];
}

const AssignDroneModal: React.FC<AssignDroneModalProps> = ({ isOpen, onClose, onAssign, patient, availableDrones }) => {
  const [selectedDroneId, setSelectedDroneId] = useState<string | null>(null);
  const { t } = useTranslations();

  if (!isOpen || !patient) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedDroneId) {
      onAssign(selectedDroneId);
      setSelectedDroneId(null);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-brand-surface rounded-lg shadow-xl w-full max-w-lg m-4 border border-brand-secondary/50">
        <div className="p-6 border-b border-brand-secondary/30">
          <h2 className="text-xl font-bold text-brand-text-primary">{t('assignDroneTo')} <span className="text-brand-primary">{patient.name}</span></h2>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-6 max-h-80 overflow-y-auto">
            <p className="text-sm text-brand-text-secondary mb-4">{t('selectAvailableDrone')}</p>
            {availableDrones.length > 0 ? (
                <fieldset className="space-y-3">
                {availableDrones.map((drone) => (
                  <label
                    key={drone.id}
                    htmlFor={drone.id}
                    className={`flex items-center justify-between p-4 rounded-lg border transition-all duration-200 cursor-pointer ${selectedDroneId === drone.id ? 'bg-brand-primary/20 border-brand-primary' : 'bg-brand-background/50 border-brand-secondary/50 hover:border-brand-secondary'}`}
                  >
                    <div>
                        <p className="font-bold text-brand-text-primary">{drone.name}</p>
                        <p className="text-sm text-brand-text-secondary">{drone.id}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                        <span className="text-sm font-semibold text-brand-primary">{drone.accuracy?.toFixed(1)}%</span>
                        <p className="text-xs text-brand-text-secondary">Accuracy</p>
                        <input
                            type="radio"
                            id={drone.id}
                            name="drone-selection"
                            value={drone.id}
                            checked={selectedDroneId === drone.id}
                            onChange={(e) => setSelectedDroneId(e.target.value)}
                            className="h-4 w-4 text-brand-primary bg-brand-background border-brand-secondary/50 focus:ring-brand-primary"
                        />
                    </div>
                  </label>
                ))}
              </fieldset>
            ) : (
                <div className="text-center py-8 px-4 bg-brand-background/50 rounded-lg">
                    <p className="text-brand-text-secondary font-semibold">{t('noDronesAvailable')}</p>
                    <p className="text-sm text-brand-text-secondary/80 mt-1">{t('noDronesAvailableDetail')}</p>
                </div>
            )}
          </div>
          <div className="px-6 py-4 bg-brand-background/50 flex justify-end space-x-3 rounded-b-lg">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-brand-text-secondary/20 text-brand-text-primary rounded-md hover:bg-brand-text-secondary/40"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              disabled={!selectedDroneId}
              className="px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary disabled:opacity-50"
            >
              {t('confirmAssignment')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AssignDroneModal;