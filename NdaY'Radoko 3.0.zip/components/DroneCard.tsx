
import React from 'react';
import { Drone, DroneStatus } from '../types';
import StatusBadge from './StatusBadge';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { useTranslations } from '../LanguageContext';

interface DroneCardProps {
  drone: Drone;
  onConfigureProm: (id: string) => void;
  onRunDiagnostics: (id: string) => void;
  onDecommission: (id: string) => void;
  onViewActivityLog: (id: string) => void;
  countryName?: string;
}

const ActionButton: React.FC<{
  onClick: () => void;
  disabled?: boolean;
  children: React.ReactNode;
  className?: string;
}> = ({ onClick, disabled = false, children, className = '' }) => (
  <button
    onClick={onClick}
    disabled={disabled}
    className={`px-4 py-2 text-sm font-semibold rounded-md transition-all duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-brand-surface focus:ring-brand-primary disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
  >
    {children}
  </button>
);

const DroneCard: React.FC<DroneCardProps> = ({ drone, onConfigureProm, onRunDiagnostics, onDecommission, onViewActivityLog, countryName }) => {
  const { t } = useTranslations();
  const isActionable = ![DroneStatus.InProgress, DroneStatus.Decommissioned, DroneStatus.Diagnosing].includes(drone.status);
  const isBusy = drone.status === DroneStatus.Diagnosing || drone.status === DroneStatus.InProgress;

  const accuracyData = drone.accuracy ? [
    { name: 'Accuracy', value: drone.accuracy },
    { name: 'Margin', value: 100 - drone.accuracy },
  ] : [];
  const COLORS = ['#00A8E8', '#1B263B'];

  return (
    <div className="bg-brand-surface rounded-lg shadow-lg overflow-hidden border border-brand-secondary/30 transition-all duration-300 hover:shadow-brand-primary/20 hover:border-brand-primary/50 flex flex-col">
      <div className="p-6 flex-grow">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm font-medium text-brand-primary">{drone.id}</p>
            <h3 className="text-xl font-bold text-brand-text-primary mt-1">{drone.name}</h3>
          </div>
          <StatusBadge status={drone.status} />
        </div>

        {drone.countryId && drone.ageProtocol && (
             <div className="mt-2 text-xs text-brand-text-secondary bg-brand-background/50 rounded-full px-3 py-1 inline-block">
                Protocol: {countryName} - {t(drone.ageProtocol === 'Young Infant' ? 'youngInfant' : 'child')}
             </div>
        )}

        {drone.status === DroneStatus.InProgress && (
          <div className="mt-4">
            <p className="text-sm text-brand-text-secondary mb-1">{t('promProgress')}</p>
            <div className="w-full bg-brand-background rounded-full h-2.5">
              <div className="bg-brand-primary h-2.5 rounded-full animate-pulse"></div>
            </div>
          </div>
        )}

        {drone.status === DroneStatus.Diagnosing && (
           <div className="mt-4 text-center p-2 bg-status-yellow/10 rounded-md">
            <p className="text-sm text-status-yellow font-semibold animate-pulse">{t('analyzingPatientData')}</p>
           </div>
        )}
        
        {drone.status === DroneStatus.Decommissioned && (
          <div className="mt-4 p-3 bg-brand-background/50 rounded-lg text-sm">
            <p className="font-bold text-brand-text-secondary">{t('reasonForDecommissioning')}:</p>
            <p className="text-brand-text-primary mb-2">{drone.decommissionReason || 'N/A'}</p>
            <p className="font-bold text-brand-text-secondary">{t('recommissioningActions')}:</p>
            <p className="text-brand-text-primary whitespace-pre-wrap">{drone.recommendedActions || 'N/A'}</p>
          </div>
        )}


        {[DroneStatus.Active, DroneStatus.Success].includes(drone.status) && drone.accuracy && (
          <div className="mt-6 flex items-center justify-center text-center">
             <div style={{ width: 100, height: 100 }}>
               <ResponsiveContainer>
                 <PieChart>
                   <Pie
                     data={accuracyData}
                     cx="50%"
                     cy="50%"
                     innerRadius={30}
                     outerRadius={40}
                     fill="#8884d8"
                     paddingAngle={5}
                     dataKey="value"
                     stroke="none"
                   >
                     {accuracyData.map((_entry, index) => (
                       <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                     ))}
                   </Pie>
                 </PieChart>
               </ResponsiveContainer>
             </div>
             <div className="ml-4">
                <p className="text-sm text-brand-text-secondary">{t('diagnosticAccuracy')}</p>
                <p className="text-3xl font-bold text-brand-primary">{drone.accuracy.toFixed(1)}%</p>
             </div>
          </div>
        )}
      </div>

      <div className="bg-brand-surface/50 px-6 py-4 flex items-center justify-end flex-wrap gap-2">
        {drone.status === DroneStatus.Pending && (
          <ActionButton onClick={() => onConfigureProm(drone.id)} className="bg-brand-primary text-white hover:bg-brand-secondary" disabled={isBusy}>
            {t('initiateProm')}
          </ActionButton>
        )}
         {[DroneStatus.Success, DroneStatus.Active, DroneStatus.Failed].includes(drone.status) && (
          <ActionButton onClick={() => onConfigureProm(drone.id)} className="bg-brand-primary text-white hover:bg-brand-secondary" disabled={isBusy}>
            {t('updateIMCIPROM')}
          </ActionButton>
        )}
        {[DroneStatus.Success, DroneStatus.Active].includes(drone.status) && (
          <ActionButton onClick={() => onRunDiagnostics(drone.id)} className="bg-status-green text-white hover:bg-green-600" disabled={isBusy}>
            {t('runSelfDiagnostics')}
          </ActionButton>
        )}
        {drone.status !== DroneStatus.Pending && (
             <ActionButton onClick={() => onViewActivityLog(drone.id)} className="bg-brand-text-secondary/50 text-white hover:bg-brand-text-secondary/80">
               {t('viewLog')}
             </ActionButton>
        )}
        {isActionable && drone.status !== DroneStatus.Pending && (
           <ActionButton onClick={() => onDecommission(drone.id)} className="bg-status-red/80 text-white hover:bg-status-red" disabled={isBusy}>
             {t('decommission')}
           </ActionButton>
        )}
      </div>
    </div>
  );
};

export default DroneCard;