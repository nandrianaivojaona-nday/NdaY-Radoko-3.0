
import React, { useState, useEffect } from 'react';
import { Drone, Patient } from '../types';
import { useTranslations } from '../LanguageContext';

interface DiagnosticReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  drone: Drone | null;
  patient: Patient | null;
  report: string | null;
  isLoading: boolean;
}

const DIAGNOSTIC_PHASES = [
  'Initializing AI Core...',
  'Verifying Sensor Array...',
  'Calibrating Flight Stabilizers...',
  'Running IMCI Protocol Simulation...',
  'Compiling Final Report...',
];
const PHASE_DURATION = 700; // ms per phase

// Helper Icon components
const CheckIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

const SpinnerIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" {...props} className={`animate-spin ${props.className}`}>
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
);

const PendingIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);


const DiagnosticReportModal: React.FC<DiagnosticReportModalProps> = ({ isOpen, onClose, drone, patient, report, isLoading }) => {
  const [completedPhases, setCompletedPhases] = useState<number[]>([]);
  const { t } = useTranslations();

  useEffect(() => {
    if (isOpen && isLoading && !patient) { // Only run for self-diagnostics
      setCompletedPhases([]); // Reset on open
      
      const timeouts: number[] = [];

      DIAGNOSTIC_PHASES.forEach((_, index) => {
        const timeout = setTimeout(() => {
          setCompletedPhases(prev => [...prev, index]);
        }, (index + 1) * PHASE_DURATION);
        timeouts.push(timeout);
      });

      return () => { // Cleanup
        timeouts.forEach(clearTimeout);
      };
    }
  }, [isOpen, isLoading, patient]);


  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-brand-surface rounded-lg shadow-xl w-full max-w-2xl m-4 border border-brand-secondary/50 flex flex-col max-h-[90vh]">
        <div className="p-6 border-b border-brand-secondary/30">
            {patient ? (
                <>
                    <h2 className="text-xl font-bold text-brand-text-primary">{t('diagnosticReport')}: <span className="text-brand-primary">{patient.name}</span></h2>
                    <p className="text-sm text-brand-text-secondary mt-1">
                        {t('analyzedBy')}: {drone?.name ?? 'N/A'} ({drone?.id ?? 'N/A'})
                    </p>
                </>
            ) : (
                 <h2 className="text-xl font-bold text-brand-text-primary">{t('selfDiagnosticReport')}: <span className="text-brand-primary">{drone?.name}</span></h2>
            )}
        </div>
        <div className="p-6 overflow-y-auto flex-grow">
          {isLoading ? (
            !patient && drone ? ( // Self-diagnostic loading view
                <div>
                    <h3 className="font-bold text-brand-text-primary mb-4 text-center">{t('runningSystemsCheck')}</h3>
                    <ul className="space-y-3">
                        {DIAGNOSTIC_PHASES.map((phase, index) => {
                        const isCompleted = completedPhases.includes(index);
                        const isInProgress = completedPhases.length === index;

                        return (
                            <li key={phase} className="flex items-center text-sm p-2 bg-brand-background/30 rounded-md">
                            {isCompleted ? (
                                <CheckIcon className="w-5 h-5 text-status-green mr-3 flex-shrink-0" />
                            ) : isInProgress ? (
                                <SpinnerIcon className="w-5 h-5 text-brand-primary mr-3 flex-shrink-0" />
                            ) : (
                                <PendingIcon className="w-5 h-5 text-brand-text-secondary/50 mr-3 flex-shrink-0" />
                            )}
                            <span className={`transition-colors duration-300 ${isCompleted ? 'text-brand-text-secondary' : isInProgress ? 'text-brand-text-primary font-semibold' : 'text-brand-text-secondary/70'}`}>
                                {phase}
                            </span>
                            {isCompleted && <span className="ml-auto text-xs font-semibold text-status-green">OK</span>}
                            </li>
                        );
                        })}
                    </ul>
                </div>
            ) : ( // Patient diagnostic loading view
                <div className="flex flex-col items-center justify-center h-64">
                    <svg className="animate-spin h-10 w-10 text-brand-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <p className="mt-4 text-brand-text-secondary">{t('aiAnalyzingSymptoms')}</p>
                </div>
            )
          ) : (
             <>
                {patient && (
                    <div className="mb-6 p-4 bg-brand-background/50 rounded-lg">
                        <h3 className="font-bold text-brand-text-primary mb-2">{t('patientVitalsSymptoms')}</h3>
                        <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
                            <p><strong className="text-brand-text-secondary">{t('age')}:</strong> {patient.age}</p>
                            <div>
                               <strong className="text-brand-text-secondary">{t('symptoms')}:</strong>
                               <div className="flex flex-wrap gap-2 mt-1">
                                {patient.symptoms.map(symptom => (
                                    <span key={symptom} className="bg-status-red/20 text-status-red px-2 py-0.5 rounded-full text-xs font-semibold">{symptom}</span>
                                ))}
                               </div>
                            </div>
                        </div>
                    </div>
                )}
                <div className="prose prose-invert prose-p:text-brand-text-secondary prose-strong:text-brand-text-primary whitespace-pre-wrap">
                  {report}
                </div>
            </>
          )}
        </div>
        <div className="px-6 py-4 bg-brand-background/50 flex justify-end rounded-b-lg">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary"
          >
            {t('close')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default DiagnosticReportModal;
