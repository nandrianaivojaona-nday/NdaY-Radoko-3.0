import React, { useState, useEffect } from 'react';
import { Drone, Country, AgeProtocol } from '../types';
import { useTranslations } from '../LanguageContext';

interface PromConfigurationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (droneId: string, ageProtocol: AgeProtocol) => void;
  drone: Drone | null;
  countries: Country[];
}

const PromConfigurationModal: React.FC<PromConfigurationModalProps> = ({ isOpen, onClose, onConfirm, drone, countries }) => {
  const [selectedAgeProtocol, setSelectedAgeProtocol] = useState<AgeProtocol | ''>('');
  const { t } = useTranslations();

  useEffect(() => {
    if (drone) {
      setSelectedAgeProtocol(drone.ageProtocol || '');
    }
  }, [drone]);

  if (!isOpen || !drone) return null;
  
  const countryName = countries.find(c => c.id === drone.countryId)?.name || drone.countryId;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedAgeProtocol) {
      onConfirm(drone.id, selectedAgeProtocol);
    }
  };
  
  const isFormInvalid = !selectedAgeProtocol;

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-brand-surface rounded-lg shadow-xl w-full max-w-md m-4 border border-brand-secondary/50">
        <div className="p-6 border-b border-brand-secondary/30">
          <h2 className="text-xl font-bold text-brand-text-primary">{t('configurePromTitle')}</h2>
          <p className="text-sm text-brand-text-secondary mt-1">{t('configurePromSubtitle')} <span className="font-semibold text-brand-primary">{countryName}</span>.</p>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-6 space-y-4">
            <div>
              <span className="block text-sm font-medium text-brand-text-secondary mb-2">{t('ageProtocol')}</span>
              <div className="grid grid-cols-2 gap-3">
                {(['Young Infant', 'Child'] as AgeProtocol[]).map(protocol => (
                  <label key={protocol} className={`block p-3 border rounded-md cursor-pointer transition-colors duration-200 ${selectedAgeProtocol === protocol ? 'bg-brand-primary/20 border-brand-primary' : 'border-brand-secondary/50 hover:border-brand-secondary'}`}>
                    <input
                      type="radio"
                      name="age-protocol"
                      value={protocol}
                      checked={selectedAgeProtocol === protocol}
                      onChange={(e) => setSelectedAgeProtocol(e.target.value as AgeProtocol)}
                      className="sr-only"
                    />
                    <span className="font-semibold text-brand-text-primary">{t(protocol === 'Young Infant' ? 'youngInfant' : 'child')}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
          <div className="px-6 py-4 bg-brand-background/50 flex justify-end space-x-3 rounded-b-lg">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-brand-text-secondary/20 text-brand-text-primary rounded-md hover:bg-brand-text-secondary/40"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              disabled={isFormInvalid}
              className="px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary disabled:opacity-50"
            >
              {t('confirmAndProgram')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PromConfigurationModal;