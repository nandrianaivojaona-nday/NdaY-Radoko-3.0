
import React, { useState } from 'react';
import { Country, Language, AgeProtocol, PlanQuarter, PlanMilestone, PlanActivity, TaskStatus } from '../types';
import { useTranslations } from '../LanguageContext';
import { parseImciProtocol } from '../services/geminiService';
import { WORLD_COUNTRIES } from '../constants';

// Helper component for tabs
const TabButton: React.FC<{
  name: string;
  activeTab: string;
  onClick: (name: string) => void;
  children: React.ReactNode;
}> = ({ name, activeTab, onClick, children }) => (
  <button
    onClick={() => onClick(name)}
    className={`px-4 py-3 text-sm font-bold transition-colors duration-200 focus:outline-none ${
      activeTab === name
        ? 'border-b-2 border-brand-primary text-brand-primary'
        : 'text-brand-text-secondary hover:text-brand-text-primary'
    }`}
  >
    {children}
  </button>
);

// Status Badge for Plan
const TaskStatusBadge: React.FC<{ status: TaskStatus }> = ({ status }) => {
    const { t } = useTranslations();
    const statusConfig = {
        [TaskStatus.NotStarted]: { color: 'bg-status-gray/20 text-status-gray', label: t('notStarted') },
        [TaskStatus.InProgress]: { color: 'bg-status-blue/20 text-status-blue', label: t('inProgress') },
        [TaskStatus.Completed]: { color: 'bg-status-green/20 text-status-green', label: t('completed') },
    };
    const config = statusConfig[status];
    return <span className={`inline-block px-2 py-0.5 text-xs font-semibold rounded-full ${config.color}`}>{config.label}</span>;
};


// Main Component for the PROM Development Plan
const PromDevelopmentPlan: React.FC<{
    plan: PlanQuarter[];
    onUpdateStatus: (qName: string, mDesc: string, aDesc: string, status: TaskStatus) => void;
}> = ({ plan, onUpdateStatus }) => {
    const { t } = useTranslations();
    const [openQuarter, setOpenQuarter] = useState<string | null>(plan[0]?.name || null);

    const handleToggleQuarter = (quarterName: string) => {
        setOpenQuarter(prev => (prev === quarterName ? null : quarterName));
    };

    const getStatusSelectClass = (status: TaskStatus) => {
        switch (status) {
            case TaskStatus.Completed: return 'bg-status-green/20 border-status-green/50 text-status-green';
            case TaskStatus.InProgress: return 'bg-status-blue/20 border-status-blue/50 text-status-blue';
            default: return 'bg-brand-background border-brand-secondary/50 text-brand-text-secondary';
        }
    };
    
    return (
        <div className="bg-brand-surface rounded-lg border border-brand-secondary/30">
            {plan.map(quarter => (
                <div key={quarter.name} className="border-b border-brand-secondary/30 last:border-b-0">
                    <button onClick={() => handleToggleQuarter(quarter.name)} className="w-full flex justify-between items-center p-4 text-left hover:bg-brand-surface/50">
                         <div>
                            <p className="text-xs font-semibold text-brand-primary uppercase tracking-wider">{t('quarter')} {quarter.name.split(' ')[1]}</p>
                            <h4 className="font-bold text-brand-text-primary mt-1">{quarter.title}</h4>
                        </div>
                        <svg className={`w-5 h-5 transition-transform duration-300 ${openQuarter === quarter.name ? 'rotate-180' : ''}`} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
                           <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
                        </svg>
                    </button>
                    {openQuarter === quarter.name && (
                        <div className="p-4 bg-brand-background/30">
                            {quarter.milestones.map(milestone => (
                                <div key={milestone.description} className="mb-6 last:mb-0 p-4 border border-brand-secondary/30 rounded-lg bg-brand-surface/50">
                                    <h5 className="font-semibold text-brand-primary text-lg">{milestone.description}</h5>
                                    <div className="mt-4 space-y-4">
                                        {milestone.activities.map(activity => (
                                            <div key={activity.description} className="p-4 bg-brand-background rounded-md border border-brand-secondary/20">
                                                <div className="flex justify-between items-start">
                                                    <p className="font-bold text-brand-text-primary flex-1 pr-4">{activity.description}</p>
                                                    <select 
                                                        value={activity.status}
                                                        onChange={(e) => onUpdateStatus(quarter.name, milestone.description, activity.description, e.target.value as TaskStatus)}
                                                        className={`text-xs font-bold py-1 pl-2 pr-7 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary ${getStatusSelectClass(activity.status)}`}
                                                    >
                                                        <option value={TaskStatus.NotStarted}>{t('notStarted')}</option>
                                                        <option value={TaskStatus.InProgress}>{t('inProgress')}</option>
                                                        <option value={TaskStatus.Completed}>{t('completed')}</option>
                                                    </select>
                                                </div>
                                                <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3 text-sm">
                                                    <div>
                                                        <p className="font-semibold text-brand-text-secondary/80">{t('expectedChanges')}:</p>
                                                        <p className="text-brand-text-secondary">{activity.expectedChanges}</p>
                                                    </div>
                                                     <div>
                                                        <p className="font-semibold text-brand-text-secondary/80">{t('signsOfSuccess')}:</p>
                                                        <p className="text-brand-text-secondary">{activity.signsOfSuccess}</p>
                                                    </div>
                                                     <div>
                                                        <p className="font-semibold text-brand-text-secondary/80">{t('dataGenerated')}:</p>
                                                        <p className="text-brand-text-secondary">{activity.dataGenerated}</p>
                                                    </div>
                                                     <div>
                                                        <p className="font-semibold text-brand-text-secondary/80">{t('keyPersonnel')}:</p>
                                                        <p className="text-brand-text-secondary">{activity.keyPersonnel}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            ))}
        </div>
    );
};

// Main AdminPage Component
interface AdminPageProps {
  countries: Country[];
  onAddCountry: (country: Omit<Country, 'id' | 'isImplemented'>) => void;
  onToggleImplementation: (countryId: string) => void;
  onStartPromTraining: (countryId: string) => void;
  implementationPlan: PlanQuarter[];
  onUpdateActivityStatus: (qName: string, mDesc: string, aDesc: string, status: TaskStatus) => void;
}

const AdminPage: React.FC<AdminPageProps> = ({ countries, onAddCountry, onToggleImplementation, onStartPromTraining, implementationPlan, onUpdateActivityStatus }) => {
  const { t } = useTranslations();
  const [activeTab, setActiveTab] = useState('countries');
  const [newCountryName, setNewCountryName] = useState('');
  const [localLanguage, setLocalLanguage] = useState<Language>('en');
  const [youngInfantProtocol, setYoungInfantProtocol] = useState('');
  const [childProtocol, setChildProtocol] = useState('');

  const [isParsingYoungInfant, setIsParsingYoungInfant] = useState(false);
  const [youngInfantFileName, setYoungInfantFileName] = useState<string | null>(null);
  const [youngInfantParseError, setYoungInfantParseError] = useState<string | null>(null);
  
  const [isParsingChild, setIsParsingChild] = useState(false);
  const [childFileName, setChildFileName] = useState<string | null>(null);
  const [childParseError, setChildParseError] = useState<string | null>(null);

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>, protocol: AgeProtocol) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const isYoungInfant = protocol === 'Young Infant';
    const setParsing = isYoungInfant ? setIsParsingYoungInfant : setIsParsingChild;
    const setFileName = isYoungInfant ? setYoungInfantFileName : setChildFileName;
    const setError = isYoungInfant ? setYoungInfantParseError : setChildParseError;
    const setProtocol = isYoungInfant ? setYoungInfantProtocol : setChildProtocol;

    setFileName(file.name);
    setParsing(true);
    setError(null);

    const reader = new FileReader();
    reader.onload = async (e) => {
        const dataUrl = e.target?.result as string;
        const base64Data = dataUrl.split(',')[1];
        if (!base64Data) {
            setError("Error reading file content.");
            setParsing(false);
            return;
        }

        try {
            const parsedText = await parseImciProtocol(base64Data, file.type, protocol);
            setProtocol(parsedText);
        } catch (error) {
            setError(t('parseError'));
            console.error(error);
        } finally {
            setParsing(false);
        }
    };
    reader.onerror = () => {
        setError("Error reading file.");
        setParsing(false);
    };
    reader.readAsDataURL(file);
    event.target.value = ''; // Allow re-uploading the same file
  };


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newCountryName) {
      onAddCountry({
        name: newCountryName,
        localLanguage,
        youngInfantProtocol,
        childProtocol,
      });
      // Reset form
      setNewCountryName('');
      setLocalLanguage('en');
      setYoungInfantProtocol('');
      setChildProtocol('');
      setYoungInfantFileName(null);
      setYoungInfantParseError(null);
      setChildFileName(null);
      setChildParseError(null);
    }
  };
  
  const renderFileUploadStatus = (isParsing: boolean, fileName: string | null, error: string | null) => {
      if (isParsing) {
           return (
                <div className="flex items-center text-brand-primary mt-2">
                    <svg className="animate-spin h-4 w-4 mr-2 text-brand-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <span className="text-xs font-semibold">{t('parsingProtocol')}</span>
                </div>
            );
      }
      if (error) {
           return <p className="mt-2 text-xs text-status-red">{error}</p>
      }
      if (fileName) {
          return (
             <div className="flex items-center text-brand-text-secondary mt-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2 text-status-green" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <span className="text-xs">{fileName}</span>
            </div>
          );
      }
      return null;
  }

  return (
    <div className="space-y-8">
        <h2 className="text-3xl font-bold text-brand-text-primary">{t('adminConsole')}</h2>
        <div className="flex border-b border-brand-secondary/30">
            <TabButton name="countries" activeTab={activeTab} onClick={setActiveTab}>{t('countryManagement')}</TabButton>
            <TabButton name="plan" activeTab={activeTab} onClick={setActiveTab}>{t('promDevelopmentPlan')}</TabButton>
        </div>

        {activeTab === 'countries' && (
            <div className="space-y-8">
                <div>
                    <h3 className="text-2xl font-bold text-brand-text-primary mb-6">{t('countryManagement')}</h3>
                    <div className="bg-brand-surface rounded-lg p-6 border border-brand-secondary/30">
                    <ul className="space-y-3">
                        {countries.map(country => (
                        <li key={country.id} className="p-4 bg-brand-background/50 rounded-md flex justify-between items-center">
                            <div>
                                <p className="font-semibold text-brand-text-primary">{country.name}</p>
                                <p className="text-sm text-brand-text-secondary">{country.localLanguage.toUpperCase()}</p>
                            </div>
                            <div className="flex items-center gap-4">
                                <button
                                    onClick={() => onStartPromTraining(country.id)}
                                    className="px-3 py-1 text-xs font-bold rounded-full bg-brand-secondary/80 text-white hover:bg-brand-secondary"
                                >
                                    {t('trainProm')}
                                </button>
                                <button
                                    onClick={() => onToggleImplementation(country.id)}
                                    className={`px-3 py-1 text-xs font-bold rounded-full ${country.isImplemented ? 'bg-status-green/20 text-status-green hover:bg-status-green/30' : 'bg-status-gray/20 text-status-gray hover:bg-status-gray/30'}`}
                                >
                                {country.isImplemented ? t('implemented') : t('notImplemented')}
                                </button>
                            </div>
                        </li>
                        ))}
                    </ul>
                    </div>
                </div>
                 <div>
                    <h3 className="text-2xl font-bold text-brand-text-primary mb-6">{t('addNewCountry')}</h3>
                    <form onSubmit={handleSubmit} className="bg-brand-surface rounded-lg p-6 border border-brand-secondary/30 space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="country-name" className="block text-sm font-medium text-brand-text-secondary mb-2">{t('countryName')}</label>
                                <input id="country-name" type="text" list="country-list" value={newCountryName} onChange={e => setNewCountryName(e.target.value)} required className="w-full bg-brand-background border border-brand-secondary/50 rounded-md px-3 py-2 text-brand-text-primary focus:outline-none focus:ring-2 focus:ring-brand-primary" placeholder="Type or select a country" />
                                <datalist id="country-list">
                                    {WORLD_COUNTRIES.map(country => (
                                        <option key={country} value={country} />
                                    ))}
                                </datalist>
                            </div>
                            <div>
                                <label htmlFor="local-language" className="block text-sm font-medium text-brand-text-secondary mb-2">{t('localLanguage')}</label>
                                <select id="local-language" value={localLanguage} onChange={e => setLocalLanguage(e.target.value as Language)} required className="w-full bg-brand-background border border-brand-secondary/50 rounded-md px-3 py-2 text-brand-text-primary focus:outline-none focus:ring-2 focus:ring-brand-primary">
                                    <option value="en">English</option>
                                    <option value="fr">Français</option>
                                    <option value="es">Español</option>
                                    <option value="de">Deutsch</option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <div className="flex justify-between items-baseline mb-1">
                                <label htmlFor="young-infant-protocol" className="block text-sm font-medium text-brand-text-secondary">{t('youngInfantProtocol')}</label>
                                <label className="relative cursor-pointer bg-brand-secondary text-white font-semibold px-3 py-1 text-xs rounded-md hover:bg-brand-primary transition-colors duration-200">
                                    <span>{youngInfantFileName ? t('changeFile') : t('selectFile')}</span>
                                    <input type="file" className="sr-only" onChange={(e) => handleFileChange(e, 'Young Infant')} accept=".txt,.md,.pdf" />
                                </label>
                            </div>
                            <p className="text-xs text-brand-text-secondary/70 mb-2">{t('fileToParseProtocolSingular')}</p>
                            <textarea id="young-infant-protocol" value={youngInfantProtocol} onChange={e => setYoungInfantProtocol(e.target.value)} rows={4} className="w-full bg-brand-background border border-brand-secondary/50 rounded-md px-3 py-2 text-brand-text-primary focus:outline-none focus:ring-2 focus:ring-brand-primary" placeholder={t('protocolPlaceholder')} />
                            {renderFileUploadStatus(isParsingYoungInfant, youngInfantFileName, youngInfantParseError)}
                        </div>

                        <div>
                            <div className="flex justify-between items-baseline mb-1">
                                <label htmlFor="child-protocol" className="block text-sm font-medium text-brand-text-secondary">{t('childProtocol')}</label>
                                <label className="relative cursor-pointer bg-brand-secondary text-white font-semibold px-3 py-1 text-xs rounded-md hover:bg-brand-primary transition-colors duration-200">
                                    <span>{childFileName ? t('changeFile') : t('selectFile')}</span>
                                    <input type="file" className="sr-only" onChange={(e) => handleFileChange(e, 'Child')} accept=".txt,.md,.pdf" />
                                </label>
                            </div>
                            <p className="text-xs text-brand-text-secondary/70 mb-2">{t('fileToParseProtocolSingular')}</p>
                            <textarea id="child-protocol" value={childProtocol} onChange={e => setChildProtocol(e.target.value)} rows={4} className="w-full bg-brand-background border border-brand-secondary/50 rounded-md px-3 py-2 text-brand-text-primary focus:outline-none focus:ring-2 focus:ring-brand-primary" placeholder={t('protocolPlaceholder')} />
                            {renderFileUploadStatus(isParsingChild, childFileName, childParseError)}
                        </div>
                        
                        <div className="flex justify-end">
                            <button type="submit" className="px-5 py-2.5 bg-brand-primary text-white font-semibold rounded-lg shadow-md hover:bg-brand-secondary transition-colors duration-300 disabled:opacity-50" disabled={!newCountryName}>
                                {t('addCountry')}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        )}
        {activeTab === 'plan' && (
            <div>
                 <h3 className="text-2xl font-bold text-brand-text-primary mb-6">{t('promDevelopmentPlan')}</h3>
                 <PromDevelopmentPlan plan={implementationPlan} onUpdateStatus={onUpdateActivityStatus} />
            </div>
        )}
    </div>
  );
};

export default AdminPage;