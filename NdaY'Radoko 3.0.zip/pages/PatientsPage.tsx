import React from 'react';
import { Patient } from '../types';
import PatientCard from '../components/PatientCard';
import { useTranslations } from '../LanguageContext';

interface PatientsPageProps {
  patients: Patient[];
  activeCountryId: string | null;
  onAddPatientClick: () => void;
  onAssignDrone: (patient: Patient) => void;
  onViewReport: (patient: Patient) => void;
}

const Placeholder: React.FC<{ message: string }> = ({ message }) => (
    <div className="flex items-center justify-center h-96 bg-brand-surface/50 rounded-lg border-2 border-dashed border-brand-secondary/30">
        <p className="text-brand-text-secondary text-lg font-semibold">{message}</p>
    </div>
);

const PatientsPage: React.FC<PatientsPageProps> = ({
  patients,
  activeCountryId,
  onAddPatientClick,
  onAssignDrone,
  onViewReport,
}) => {
  const { t } = useTranslations();
  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold text-brand-text-primary">{t('patientTriage')}</h2>
        <button
          onClick={onAddPatientClick}
          disabled={!activeCountryId}
          className="flex items-center px-4 py-2 bg-brand-secondary text-white font-semibold rounded-lg shadow-md hover:bg-brand-primary transition-colors duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
          </svg>
          {t('registerPatient')}
        </button>
      </div>
       {!activeCountryId ? (
        <Placeholder message={t('selectCountryToViewPatients')} />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {patients.map(patient => (
            <PatientCard
              key={patient.id}
              patient={patient}
              onAssignDrone={onAssignDrone}
              onViewReport={onViewReport}
            />
          ))}
        </div>
       )}
    </>
  );
};

export default PatientsPage;