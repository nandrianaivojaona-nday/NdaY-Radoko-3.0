
import React from 'react';
import { Country } from '../types';
import { useTranslations } from '../LanguageContext';

interface HomePageProps {
  countries: Country[];
  onSelectCountryAndNavigate: (countryId: string) => void;
}

const hasContextualProtocol = (country: Country): boolean => {
    const youngInfantIsContextual = country.youngInfantProtocol && !country.youngInfantProtocol.startsWith('Default');
    const childIsContextual = country.childProtocol && !country.childProtocol.startsWith('Default');
    return youngInfantIsContextual || childIsContextual;
};

const HomePage: React.FC<HomePageProps> = ({ countries, onSelectCountryAndNavigate }) => {
    const { t } = useTranslations();

  return (
    <div className="space-y-12">
        <div className="text-center p-8 bg-brand-surface rounded-lg border border-brand-secondary/30">
            <h1 className="text-4xl font-bold text-brand-primary">{t('welcomeTitle')}</h1>
            <p className="mt-2 text-lg text-brand-text-secondary">{t('welcomeSubtitle')}</p>
        </div>

        <div>
            <h3 className="text-2xl font-bold text-brand-text-primary mb-6">{t('allCountries')}</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {countries.map(country => (
                    <div key={country.id} className="bg-brand-surface rounded-lg border border-brand-secondary/30 flex flex-col justify-between">
                        <div className="p-6">
                            <h4 className="text-xl font-bold text-brand-text-primary">{country.name}</h4>
                            <p className="text-sm text-brand-text-secondary mt-2">{t('initiativeStatus')}</p>
                            {country.isImplemented ? (
                                <>
                                    <span className="inline-block mt-1 px-2 py-0.5 text-xs font-semibold rounded-full bg-status-green/20 text-status-green">
                                        {t('implemented')}
                                    </span>
                                    <div className="mt-3 pt-3 border-t border-brand-secondary/20">
                                        <p className="text-xs text-brand-text-secondary font-semibold">{t('protocolInUse')}:</p>
                                        <p className="text-sm font-bold text-brand-text-primary mt-1">
                                            {hasContextualProtocol(country) ? t('contextual') : t('globalWHO')}
                                        </p>
                                    </div>
                                </>
                            ) : (
                                 <span className="inline-block mt-1 px-2 py-0.5 text-xs font-semibold rounded-full bg-status-gray/20 text-status-gray">
                                    {t('notImplemented')}
                                </span>
                            )}
                        </div>
                        {country.isImplemented && (
                             <div className="p-4 bg-brand-background/50">
                                <button
                                    onClick={() => onSelectCountryAndNavigate(country.id)}
                                    className="w-full text-center px-4 py-2 text-sm font-semibold rounded-md transition-all duration-200 bg-brand-primary text-white hover:bg-brand-secondary"
                                >
                                    {t('viewDashboard')}
                                </button>
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    </div>
  );
};

export default HomePage;
