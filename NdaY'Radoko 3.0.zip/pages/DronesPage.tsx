import React from 'react';
import { Drone, Country } from '../types';
import DroneCard from '../components/DroneCard';
import { useTranslations } from '../LanguageContext';

interface DronesPageProps {
  drones: Drone[];
  countries: Country[];
  activeCountryId: string | null;
  onAddDroneClick: () => void;
  onConfigureProm: (id: string) => void;
  onRunDiagnostics: (id: string) => void;
  onDecommission: (id: string) => void;
  onViewActivityLog: (id: string) => void;
}

const Placeholder: React.FC<{ message: string }> = ({ message }) => (
    <div className="flex items-center justify-center h-96 bg-brand-surface/50 rounded-lg border-2 border-dashed border-brand-secondary/30">
        <p className="text-brand-text-secondary text-lg font-semibold">{message}</p>
    </div>
);


const DronesPage: React.FC<DronesPageProps> = ({
  drones,
  countries,
  activeCountryId,
  onAddDroneClick,
  onConfigureProm,
  onRunDiagnostics,
  onDecommission,
  onViewActivityLog,
}) => {
  const { t } = useTranslations();
  const countryMap = new Map(countries.map(c => [c.id, c.name]));

  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold text-brand-text-primary">{t('droneFleetStatus')}</h2>
        <button
          onClick={onAddDroneClick}
          disabled={!activeCountryId}
          className="flex items-center px-4 py-2 bg-brand-primary text-white font-semibold rounded-lg shadow-md hover:bg-brand-secondary transition-colors duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
          </svg>
          {t('registerDrone')}
        </button>
      </div>
      
      {!activeCountryId ? (
         <Placeholder message={t('selectCountryToViewDrones')} />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {drones.map(drone => (
            <DroneCard
              key={drone.id}
              drone={drone}
              countryName={drone.countryId ? countryMap.get(drone.countryId) : undefined}
              onConfigureProm={onConfigureProm}
              onRunDiagnostics={onRunDiagnostics}
              onDecommission={onDecommission}
              onViewActivityLog={onViewActivityLog}
            />
          ))}
        </div>
      )}
    </>
  );
};

export default DronesPage;