
import { Drone, DroneStatus, Patient, PatientStatus, Country, PlanQuarter, TaskStatus } from './types';

export const INITIAL_COUNTRIES: Country[] = [
    {
      id: 'senegal',
      name: 'Senegal',
      localLanguage: 'fr',
      youngInfantProtocol: 'Default Senegal protocol for infants under 3 months...',
      childProtocol: 'Default Senegal protocol for children 3 months to 5 years...',
      isImplemented: true,
    },
    {
      id: 'kenya',
      name: 'Kenya',
      localLanguage: 'en',
      youngInfantProtocol: 'Default Kenya protocol for infants under 3 months...',
      childProtocol: 'Default Kenya protocol for children 3 months to 5 years...',
      isImplemented: true,
    },
    {
      id: 'ghana',
      name: 'Ghana',
      localLanguage: 'en',
      youngInfantProtocol: 'Default Ghana protocol...',
      childProtocol: 'Default Ghana protocol...',
      isImplemented: false,
    },
    {
      id: 'nigeria',
      name: 'Nigeria',
      localLanguage: 'en',
      youngInfantProtocol: 'Default Nigeria protocol...',
      childProtocol: 'Default Nigeria protocol...',
      isImplemented: true,
    },
    {
      id: 'ivory-coast',
      name: 'Côte d\'Ivoire',
      localLanguage: 'fr',
      youngInfantProtocol: 'Default Côte d\'Ivoire protocol...',
      childProtocol: 'Default Côte d\'Ivoire protocol...',
      isImplemented: false,
    },
    {
      id: 'madagascar',
      name: 'Madagascar',
      localLanguage: 'fr',
      youngInfantProtocol: `ASSESS AND CLASSIFY THE SICK YOUNG INFANT AGE 1 WEEK UP TO 2 MONTHS.
CHECK FOR POSSIBLE SERIOUS BACTERIAL INFECTION OR VERY SEVERE DISEASE.
ASK: Has the infant had convulsions? Is the infant feeding poorly? Does the infant vomit everything?
LOOK, LISTEN, FEEL: Count the breaths in one minute. Repeat if elevated. Look for severe chest indrawing. Look and feel for a bulging fontanelle. Look for pus draining from the ear. Look at the umbilicus. Is it red or draining pus? Look for skin pustules. Is the infant lethargic or unconscious? Feel for fever or low body temperature.
CLASSIFY based on signs.

THEN, CHECK FOR JAUNDICE.
ASK: Has the infant had jaundice? If yes, when did it appear?
LOOK: Look for jaundice (yellow eyes or skin). Look at the infant's palms and soles. Are they yellow?
CLASSIFY for Jaundice.

THEN, ASK ABOUT DIARRHOEA.
ASK: Does the infant have diarrhoea? If yes, for how long? Is there blood in the stool?
LOOK AND FEEL: Look at the infant's general condition. Is the infant lethargic or unconscious? Restless or irritable? Look for sunken eyes. Pinch the skin of the abdomen. Does it go back very slowly?
CLASSIFY for Diarrhoea.

FINALLY, CHECK FOR HIV INFECTION.
ASK: Has the mother or infant been tested for HIV? What were the results? Is the infant breastfeeding? Has the infant been given ART?
LOOK: Look for oral thrush. Look for skin lesions.
CLASSIFY HIV status and feeding practices.`,
      childProtocol: 'Default Madagascar protocol...',
      isImplemented: false,
    }
];


export const INITIAL_DRONES: Drone[] = [
  {
    id: "IMCI-D-001",
    name: "Nightingale-7",
    status: DroneStatus.Active,
    accuracy: 98.7,
    assignedPatientId: undefined,
    activityLog: [
      { timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), event: 'PROM Successful', details: 'Country: Senegal, Protocol: Young Infant' },
      { timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), event: 'Registered to Fleet' },
    ],
    countryId: 'senegal',
    ageProtocol: 'Young Infant',
  },
  {
    id: "IMCI-D-002",
    name: "Caduceus-Prime",
    status: DroneStatus.Success,
    accuracy: 99.2,
    assignedPatientId: undefined,
    activityLog: [
        { timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), event: 'PROM Successful', details: 'Country: Kenya, Protocol: Child' },
        { timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), event: 'Registered to Fleet' },
    ],
    countryId: 'kenya',
    ageProtocol: 'Child',
  },
  {
    id: "IMCI-D-003",
    name: "MediBot-Alpha",
    status: DroneStatus.InProgress,
    accuracy: null,
    assignedPatientId: undefined,
    activityLog: [
        { timestamp: new Date().toISOString(), event: 'PROM Initiated' },
        { timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), event: 'Registered to Fleet' },
    ],
    countryId: 'senegal',
    ageProtocol: null,
  },
  {
    id: "IMCI-D-004",
    name: "Hope-Wing",
    status: DroneStatus.Pending,
    accuracy: null,
    assignedPatientId: undefined,
    activityLog: [
      { timestamp: new Date().toISOString(), event: 'Registered to Fleet' }
    ],
    countryId: 'kenya',
    ageProtocol: null,
  },
    {
    id: "IMCI-D-005",
    name: "Helix-Drone",
    status: DroneStatus.Failed,
    accuracy: null,
    assignedPatientId: undefined,
    activityLog: [
        { timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), event: 'PROM Failed' },
        { timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), event: 'Registered to Fleet' },
    ],
    countryId: 'nigeria',
    ageProtocol: null,
  },
  {
    id: "IMCI-D-006",
    name: "Serenity-Scout",
    status: DroneStatus.Decommissioned,
    accuracy: 95.1,
    assignedPatientId: undefined,
    activityLog: [
      { timestamp: new Date().toISOString(), event: 'Decommissioned' },
      { timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(), event: 'Diagnosed Patient: Infant Leo' },
      { timestamp: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(), event: 'PROM Successful' },
      { timestamp: new Date(Date.now() - 11 * 24 * 60 * 60 * 1000).toISOString(), event: 'Registered to Fleet' },
    ],
    countryId: 'senegal',
    ageProtocol: 'Child',
  },
];

export const INITIAL_PATIENTS: Patient[] = [
    {
        id: "P-001",
        name: "Baby Aisha",
        age: "3 months",
        symptoms: ["fever", "cough", "difficulty breathing"],
        status: PatientStatus.AwaitingDiagnosis,
        assignedDroneId: null,
        diagnosticReport: null,
        countryId: 'senegal',
    },
    {
        id: "P-002",
        name: "Infant Ben",
        age: "5 months",
        symptoms: ["diarrhea", "lethargy", "sunken eyes"],
        status: PatientStatus.AwaitingDiagnosis,
        assignedDroneId: null,
        diagnosticReport: null,
        countryId: 'kenya',
    },
    {
        id: "P-003",
        name: "Baby Chloe",
        age: "1 month",
        symptoms: ["poor feeding", "convulsions"],
        status: PatientStatus.AwaitingDiagnosis,
        assignedDroneId: null,
        diagnosticReport: null,
        countryId: 'senegal',
    }
];

export const WORLD_COUNTRIES: string[] = [
    "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Antigua and Barbuda", "Argentina", "Armenia", "Australia", "Austria", "Azerbaijan",
    "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Brazil", "Brunei", "Bulgaria", "Burkina Faso", "Burundi",
    "Cabo Verde", "Cambodia", "Cameroon", "Canada", "Central African Republic", "Chad", "Chile", "China", "Colombia", "Comoros", "Congo, Democratic Republic of the", "Congo, Republic of the", "Costa Rica", "Côte d'Ivoire", "Croatia", "Cuba", "Cyprus", "Czech Republic",
    "Denmark", "Djibouti", "Dominica", "Dominican Republic",
    "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Eswatini", "Ethiopia",
    "Fiji", "Finland", "France",
    "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Greece", "Grenada", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana",
    "Haiti", "Honduras", "Hungary",
    "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", "Israel", "Italy",
    "Jamaica", "Japan", "Jordan",
    "Kazakhstan", "Kenya", "Kiribati", "Kuwait", "Kyrgyzstan",
    "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg",
    "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Mauritania", "Mauritius", "Mexico", "Micronesia", "Moldova", "Monaco", "Mongolia", "Montenegro", "Morocco", "Mozambique", "Myanmar",
    "Namibia", "Nauru", "Nepal", "Netherlands", "New Zealand", "Nicaragua", "Niger", "Nigeria", "North Korea", "North Macedonia", "Norway",
    "Oman",
    "Pakistan", "Palau", "Palestine State", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Poland", "Portugal",
    "Qatar",
    "Romania", "Russia", "Rwanda",
    "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Korea", "South Sudan", "Spain", "Sri Lanka", "Sudan", "Suriname", "Sweden", "Switzerland", "Syria",
    "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Timor-Leste", "Togo", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu",
    "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States of America", "Uruguay", "Uzbekistan",
    "Vanuatu", "Vatican City", "Venezuela", "Vietnam",
    "Yemen",
    "Zambia", "Zimbabwe"
];

export const INITIAL_IMPLEMENTATION_PLAN: PlanQuarter[] = [
  {
    name: "Quarter 1",
    title: "Development of modules regarding the IMCI Chart to ASSESS, CLASSIFY AND IDENTIFY TREATMENT",
    milestones: [
      {
        description: "Refine the requirements to produce all modules.",
        activities: [
          { 
            description: "Identification of accurate sensors or devices for checking and development of all modules.",
            expectedChanges: "All three human sensors would be the base of the identification and should be replaced by identified sensors.",
            signsOfSuccess: "List of identified sensors or devices for the IMCI Chart is validated.",
            dataGenerated: "Commits on GitHUB",
            keyPersonnel: "Physician User Testing, Physician Technical Advisor, Agir Director, Digital Advisor",
            status: TaskStatus.NotStarted
          },
          { 
            description: "Adopting new sensors or devices or equipments. Review and updating all sensors, devices and others equipments needed for the project.",
            expectedChanges: "Defined and accurate sensors would be adopted.",
            signsOfSuccess: "List of new sensors or devices would be sorted out.",
            dataGenerated: "Updating GitHUB",
            keyPersonnel: "Physician User Testing, Physician Technical Advisor, Agir Director, Digital Advisor",
            status: TaskStatus.NotStarted
          },
        ],
      },
      {
        description: "Validation and feedback of already prototyped, confirming and refining the Product requirements.",
        activities: [
          { 
            description: "Refine the checking for possible serious bacterial infection, very severe disease, pneumonia or local bacterial infection.",
            expectedChanges: "The modules would meet the Physician User Testing requirements and satisfaction and be ready to test by at least two power users.",
            signsOfSuccess: "At least seven (7) things to look/check to assess the young infants and Twelve (12) signs would be coded to classify the treatment. The Physician User Testing would validate the test to two key powers users (they are to be identified during the project).",
            dataGenerated: "Collected data will be sent remotely and on real time to Database. In case of network issues, a local incorporated database can store temporary data. Then to be synchronised once network issues is restored.",
            keyPersonnel: "Digital Advisor, Key Coding staff, Physicians, Lead Coding staff, AGIR Director",
            status: TaskStatus.NotStarted
          },
          { 
            description: "Refining the module 'Then, check for jaundice'.",
            expectedChanges: "Updated module according to the validated sensor or device would be ready to be tested.",
            signsOfSuccess: "Two questions and two observations would be coded.",
            dataGenerated: "DataBase Commit on GitHUB",
            keyPersonnel: "Coding staffs",
            status: TaskStatus.NotStarted
          },
        ],
      },
      {
        description: "Production of diarrhoea modules per the sheet of 'Then, ask: does the young infant have diarrhoea?'.",
        activities: [
          { 
            description: "Identification of accurate sensors or devices for diarrhoea checking and development of the module.",
            expectedChanges: "The Diarrhoea modules would be developed according to the listed accurate sensors or devices.",
            signsOfSuccess: "Sensors and/or devices for diarrhoea checking would be identified and validated by the Physician Technical Advisor. One question to be asked, two looks to be observed and one touch to be feel, six signs to classify and a list of treatment according to the Chart would be coded.",
            dataGenerated: "Commit on GitHUB",
            keyPersonnel: "AGIR Director, Physicians, Digital Advisor. Coding Staffs",
            status: TaskStatus.NotStarted
          },
          { 
            description: "User testing product, UX and UI.",
            expectedChanges: "The modules would be ready to the user testing.",
            signsOfSuccess: "The modules would be ready to the user testing.",
            dataGenerated: "DataBase: depending on the sensors, data can be texts, voice files, picture files or both of these. The HW will have the most precise way to determine the best diagnosis. Commit on GitHUB.",
            keyPersonnel: "Digital Advisor, Physician Technical Advisor, Physician User Testing, Key Coding staffs",
            status: TaskStatus.NotStarted
          },
        ],
      },
      {
        description: "Production of module to check HIV infection and breastfed.",
        activities: [
          { 
            description: "Development of the module based on the identified approach and the accurate sensors or devices for HIV infection and breastfed.",
            expectedChanges: "HIV infection modules is coded.",
            signsOfSuccess: "Five (5) questions are being coded for assessment to lead to the classification of the diseases.",
            dataGenerated: "Commit on GitHUB",
            keyPersonnel: "Digital Advisor, Physician Technical Advisor, Key Coding staffs",
            status: TaskStatus.NotStarted
          }
        ],
      },
      {
        description: "Validation and feedback for bacterial, severe disease, pneumonia.",
        activities: [
            { 
              description: "User testing (Product and UX).",
              expectedChanges: "Two tests lead by the Physician User Testing are tested.",
              signsOfSuccess: "Three random tests are conducted with two power users.",
              dataGenerated: "DataBase Commit on GitHUB",
              keyPersonnel: "Digital Advisor, Key Coding staffs",
              status: TaskStatus.NotStarted
            },
            { 
              description: "User testing (UI).",
              expectedChanges: "Modules are ready to be prototyped.",
              signsOfSuccess: "Feedbacks are collected and checked out.",
              dataGenerated: "DataBase",
              keyPersonnel: "Physician User Testing, Coding User Interface",
              status: TaskStatus.NotStarted
            }
        ],
      },
    ],
    deliverables: {
      frontend: "Menu of the Bacterial infection, Jaunice, Diarrhoea, HIV infection and Breastfed available for users.",
      backend: "Modules of the Bacterial infection, Jaunice, Diarrhoea, HIV infection and Breastfed uploaded at the GitHub.",
    },
  },
  {
    name: "Quarter 2",
    title: "Development of the modules regarding the IMCI Chart to ASSESS, CLASSIFY AND IDENTIFY TREATMENT (cont.)",
    milestones: [
      {
        description: "Production of module per the sheet of 'Then, check for a feeding problem or low weight for age in infants not'.",
        activities: [
          { 
            description: "Validation of the module to develop by identifying the sensors and devices to be considered.",
            expectedChanges: "Sensors or devices are identified.",
            signsOfSuccess: "One sensor or device must be identified.",
            dataGenerated: "Shared information on identify sensors. Commit on GitHUB.",
            keyPersonnel: "Digital Advisor, Physician Technical advisor, Key Coding staffs",
            status: TaskStatus.NotStarted
          },
          { 
            description: "Development of the module based on the identified approach and the accurate sensors or devices.",
            expectedChanges: "Modules on feeding problem and low weight are codifying.",
            signsOfSuccess: "Five questions to ask, and one observation of weight falling in a three series of range would be coded with one look and one action to check at the assessment stage. They drive the 3 classifications and list of 16 treatments.",
            dataGenerated: "Commit on GitHUB",
            keyPersonnel: "Digital Advisor, Key Coding staffs",
            status: TaskStatus.NotStarted
          },
        ],
      },
      {
        description: "Production of module per the sheet of 'Then, check the young infant's immunization status'.",
        activities: [
          { 
            description: "Validation of the module to develop by identifying the sensors and devices to be considered.",
            expectedChanges: "Sensors or devices to check the immunization schedule identified.",
            signsOfSuccess: "One accurate and efficient sensor or device must be identified.",
            dataGenerated: "Commit on GitHUB",
            keyPersonnel: "Digital Advisor, Physician Technical Advisor, AGIR Director, Key Coding staffs",
            status: TaskStatus.NotStarted
          },
          { 
            description: "Development of the module based on the identified approach and/or the accurate sensors or devices.",
            expectedChanges: "Digital status immunization is available.",
            signsOfSuccess: "Two ages and 8 vaccines are coded in the module.",
            dataGenerated: "Every identified sensors or devices will be tracked or/ and inventoried. Software module will be committed to the Github project source. Data collected will be stored on a database.",
            keyPersonnel: "Digital Advisor, Key Coding staffs",
            status: TaskStatus.NotStarted
          },
        ],
      },
      {
        description: "Production of module per the sheet of 'Assess other problems'.",
        activities: [
          { 
            description: "Validation of the module to develop by identifying the sensors and devices to be considered.",
            expectedChanges: "Method or approach to adopt that would be transformed digitally is identified.",
            signsOfSuccess: "One method or approach or tool identified.",
            dataGenerated: "Commit on GitHUB",
            keyPersonnel: "Physician User Testing, Physician Technical Advisor, key power users, Agir Director, Digital Advisor",
            status: TaskStatus.NotStarted
          },
          { 
            description: "Development of the module based on the identified approach and/or the accurate sensors or devices.",
            expectedChanges: "A digital form to write down other problems is available.",
            signsOfSuccess: "One free form list to assess other problems is developed and coded.",
            dataGenerated: "Commit on GitHUB",
            keyPersonnel: "Digital Advisor, Key Coding staffs",
            status: TaskStatus.NotStarted
          },
        ],
      },
      {
        description: "Production of module per the sheet of 'Assess the mother's health needs'.",
        activities: [
          { 
            description: "Validation of the module to develop by discussing to identify the sensors and devices to be considered.",
            expectedChanges: "Sensor or device or tool regarding to the algorithm assess the mother's health needs is identified.",
            signsOfSuccess: "One accurate and efficient sensor or device or tool must be identified.",
            dataGenerated: "Commit on GitHUB",
            keyPersonnel: "Physician User Testing, Physician Technical Advisor, key power users, Agir Director, Digital Advisor",
            status: TaskStatus.NotStarted
          },
          { 
            description: "Development of the module based on the identified approach and/or the accurate sensors, devices or checking methods.",
            expectedChanges: "Digital assessment of mother's needs is ready to be tested by the users.",
            signsOfSuccess: "6 status to be checked and recorded are coded.",
            dataGenerated: "Commit on GitHUB",
            keyPersonnel: "Digital Advisor, Key Coding staffs",
            status: TaskStatus.NotStarted
          },
        ],
      },
      {
        description: "Validation and feedback (If applicable).",
        activities: [
          { 
            description: "User testing (Product and UX).",
            expectedChanges: "Physician User testing is ready to do a test with power users.",
            signsOfSuccess: "Two power users work closely with the Physician User Testing and the Coding User Testing. Poll results that will be collected and evaluated to determine the accuracy of the tests.",
            dataGenerated: "DataBase Commit on GitHUB",
            keyPersonnel: "Digital Advisor, Physician Technical Advisor, Physician User Testing, Key Coding staffs",
            status: TaskStatus.NotStarted
          },
          { 
            description: "User testing (UI).",
            expectedChanges: "Coding User Testing staff signed off the UI.",
            signsOfSuccess: "Power Users sign off the module.",
            dataGenerated: "DataBase",
            keyPersonnel: "Physician and coding User testing",
            status: TaskStatus.NotStarted
          },
          { 
            description: "Plea of the project.",
            expectedChanges: "Main users of the project such as USAID's, UN's and other Foundations Health Project must be contact for plea and demonstration of the 'Ndai'Radoko'.",
            signsOfSuccess: "One demonstration at a CSB is done.",
            dataGenerated: "DataBase",
            keyPersonnel: "All team and potential Funding partners",
            status: TaskStatus.NotStarted
          },
        ],
      },
    ],
    deliverables: {
      frontend: "Menu of the Assessment of young infant aged up to 2 months available for users.",
      backend: "Modules on all assessment of the young infant aged up to 2 months uploaded at the Github.",
    },
  },
  {
    name: "Quarter 3",
    title: "Development of modules that will TREAT THE SICK YOUNG INFANT, COUNSEL THE MOTHER and GIVE FOLLOW-UP CARE FOR THE SICK YOUNG INFANT, per the IMCI Chart Booklet",
    milestones: [
        {
            description: "Treat the sick young infant.",
            activities: [
                { 
                  description: "Development of the module 'Give first doses of intramuscular gentamicin and ampicillin.', then Treat the young infant to prevent low blood sugar and 'Teach the mother how to keep the young infant warm on the way to the hospital.' and 'Refer urgently.'",
                  expectedChanges: "Giving intramuscular doses is assisted by a drone. If not feasible a digital guide for referral is ready to use.",
                  signsOfSuccess: "Series of 4 actions are coded on how to give an intramuscular antibiotic.",
                  dataGenerated: "Commit on GitHUB",
                  keyPersonnel: "Digital Advisor, Key Coding staffs",
                  status: TaskStatus.NotStarted
                },
                { 
                  description: "Validation and feedback modules, and User testing (Product, UX, and UI).",
                  expectedChanges: "Modules are ready to be prototyped Physician User testing is ready to do a test with power users Coding User Testing staff signed off the UI.",
                  signsOfSuccess: "Each of the 4 actions in the serial chart is giving a POC before prototype validation.",
                  dataGenerated: "DataBase Commit on GitHUB",
                  keyPersonnel: "Physician User Testing, Physician Technical Advisor, key power users, Agir Director, Digital Advisor",
                  status: TaskStatus.NotStarted
                }
            ]
        },
        {
            description: "Teach The Mother To Give Oral Medicines At Home.",
            activities: [
                { 
                  description: "Development of the modules - Follow the instructions below to teach the mother about each oral medicine to be given at home, and the instructions listed with the dosage table for each medicine. - Give oral cotrimoxazole",
                  expectedChanges: "Giving oral antibiotic is digitalised according to the HIV case.",
                  signsOfSuccess: "The 11 instructions to follow before giving treatment on oral medicines and instructions or recommandations on how to give oral medicines with HIV case are coded.",
                  dataGenerated: "Commit on GitHUB",
                  keyPersonnel: "Digital Advisor, Key Coding staff, Physicians",
                  status: TaskStatus.NotStarted
                },
                { 
                  description: "Validation and feedback modules, and User testing (Product, UX, and UI).",
                  expectedChanges: "Modules are ready to be prototyped Physician User testing is ready to do a test with power users Coding User Testing staff signed off the UI.",
                  signsOfSuccess: "The 9 instructions on how to teach the mother to give oral medicine are given a tested POC to be ready for prototype.",
                  dataGenerated: "DataBase Commit on GitHUB",
                  keyPersonnel: "Physician User Testing, Physician Technical Advisor, key power users, Agir Director, Digital Advisor",
                  status: TaskStatus.NotStarted
                }
            ]
        },
        {
            description: "DEHYDRATION using Plan A, B, C.",
            activities: [
                { 
                  description: "Development of the modules Plan A: TREAT DIARRHOEA AT HOME; PLAN B: TREAT SOME DEHYDRATION WITH ORAL REHYDRATION SALTS (ORS); Plan C: treat severe dehydration quickly.",
                  expectedChanges: "Digital treatment of diarrhoea and severe dehydration are ready to use.",
                  signsOfSuccess: "Treatment of diarrhoea and severe dehydration are prototyped.",
                  dataGenerated: "Commit on GitHUB",
                  keyPersonnel: "Digital Advisor, Key Coding staff, Physicians",
                  status: TaskStatus.NotStarted
                },
                { 
                  description: "Development of the modules regarding to the refuse or not feasible referral.",
                  expectedChanges: "Digital classification of young infant with sever bacteria infection is available.",
                  signsOfSuccess: "14 signs falling in 3 classes that list identified treatment are coded and have given a tested POC to be ready for test after being a validate prototype.",
                  dataGenerated: "Commit on GitHUB",
                  keyPersonnel: "Digital Advisor, Key Coding staff, Physicians",
                  status: TaskStatus.NotStarted
                },
                { 
                  description: "Validation and feedback modules, and User testing (Product, UX, and UI).",
                  expectedChanges: "Modules are ready to be prototyped Physician User testing is ready to do a test with power users Coding User Testing staff signed off the UI.",
                  signsOfSuccess: "14 signs falling in 3 classes that list identified treatment are coded and have given a tested POC are user tested.",
                  dataGenerated: "DataBase Commit on GitHUB",
                  keyPersonnel: "Physician User Testing, Physician Technical Advisor, key power users, Agir Director, Digital Advisor",
                  status: TaskStatus.NotStarted
                }
            ]
        },
        {
            description: "COUNSEL THE MOTHER.",
            activities: [
                { 
                  description: "Development of the modules 'feeding recommendations', 'teach correct positioning and attachment for breastfeeding', 'Teach the mother how to express breastmilk', 'Counsel the caretaker or HIV-positive mother who is not breastfeeding', 'HOW TO PREPARE COMMERCIAL FORMULA MILK', 'Teach the mother how to keep the low-weight infant warm at home', and 'Advise the mother on giving home care to the sick young infant'.",
                  expectedChanges: "A digital counselling on those modules is available.",
                  signsOfSuccess: "The Physician User Testing approve the modules.",
                  dataGenerated: "Commit on GitHUB",
                  keyPersonnel: "Digital Advisor, Key Coding staff, Physicians",
                  status: TaskStatus.NotStarted
                },
                { 
                  description: "Validation and feedback modules, and User testing (Product, UX, and UI).",
                  expectedChanges: "Tested digital counselling is given grant to use.",
                  signsOfSuccess: "Modules are ready to be prototyped Physician User testing do at least 10 tests with random (power) users Coding User Testing staff signed off the UI.",
                  dataGenerated: "DataBase Commit on GitHUB",
                  keyPersonnel: "Physician User Testing, Physician Technical Advisor, key power users, Agir Director, Digital Advisor",
                  status: TaskStatus.NotStarted
                }
            ]
        },
        {
            description: "GIVE FOLLOW-UP CARE FOR THE SICK YOUNG INFANT.",
            activities: [
                 { 
                  description: "Development of modules : 'CRITICAL ILLNESSS WHEN REFERRAL WAS REFUSED OR NOT FEASIBLE', 'CLINICAL SEVERE INFECTION WHEN REFERRAL WAS REFUSED OR NOT FEASIBLE', 'PNEUMONIA OR SEVERE PNEUMONIA', LOCAL BACTERIAL INFECTION', 'JAUNDICE', 'DIARRHOEA', 'CONFIRMED HIV INFECTION OR HIV EXPOSED', 'FEEDING PROBLEM', 'LOW WEIGHT FOR AGE', 'THRUSH-MUGUET'",
                  expectedChanges: "Digital modules on the those items are coded.",
                  signsOfSuccess: "9 charts according to the last validated IMCI in Madagascar are coded with a sign off of the Coding User Testing.",
                  dataGenerated: "Commit on GitHUB",
                  keyPersonnel: "Digital Advisor, Key Coding staff, Physicians",
                  status: TaskStatus.NotStarted
                },
                 { 
                  description: "Validation and feedback modules, and User testing (Product, UX, and UI).",
                  expectedChanges: "Digital modules on the those items are granted to use by the Physicians.",
                  signsOfSuccess: "Modules are ready to be prototyped Physician User testing do more than 10 tests with random (power) users Coding User Testing staff signed off the UI.",
                  dataGenerated: "DataBase Commit on GitHUB",
                  keyPersonnel: "Physician User Testing, Physician Technical Advisor, key power users, Agir Director, Digital Advisor",
                  status: TaskStatus.NotStarted
                 }
            ]
        }
    ],
    deliverables: {
        frontend: "Menu of the treatment and counselling mother available.",
        backend: "Modules on all treatment and Counselling mother uploaded at the GitHub."
    }
  },
  {
    name: "Quarter 4",
    title: "Refine all modules of the IMCI for young infant under 2 months, and development of the drone controls",
    milestones: [
        {
            description: "Drone Controls.",
            activities: [
                { 
                  description: "Flying remote control.",
                  expectedChanges: "The drone is controlled remotly.",
                  signsOfSuccess: "AGIR Director is validating the flying remote control, after more than 20 random tests.",
                  dataGenerated: "Online Data Exchange DataBase Commit on GitHUB",
                  keyPersonnel: "AGIR Director, Physicians, Digital Advisor. Coding Staffs",
                  status: TaskStatus.NotStarted
                },
                { 
                  description: "Sensors and any devices remote controls.",
                  expectedChanges: "The drone acts like a human with its sensors, devices, etc.",
                  signsOfSuccess: "AGIR Director is validating the sensors and/or devices remote controls after more 20 tests are conducted.",
                  dataGenerated: "Online Data Exchange DataBase Commit on GitHUB",
                  keyPersonnel: "AGIR Director, Physicians, Digital Advisor. Coding Staffs",
                  status: TaskStatus.NotStarted
                }
            ]
        },
        {
            description: "Refine all check, assess and classify modules and theirs relations to the drone controls.",
            activities: [
                { 
                  description: "Drone Controls regarding the Checking, assess and classify Charts.",
                  expectedChanges: "The drone acts like a human with its sensors, devices, etc. to check, assess and classify.",
                  signsOfSuccess: "AGIR Director is validating the drone controls after more 20 tests are conducted.",
                  dataGenerated: "Drone Control check up list or file. Online Data Exchange DataBase Commit on GitHUB",
                  keyPersonnel: "AGIR Director, Physicians, Digital Advisor. Coding Staffs",
                  status: TaskStatus.NotStarted
                },
                { 
                  description: "Drone recording and updating data related to the modules and algorithms.",
                  expectedChanges: "Drone acts as an intelligent device to record and update data.",
                  signsOfSuccess: "AGIR Director and Lead Coding staff are validating the drone recording and update data while Digital advisor and Physicians are conducting more than 30 tests.",
                  dataGenerated: "Drone's Controls check up list or file. Online Data Exchange DataBase Commit on GitHUB.",
                  keyPersonnel: "AGIR Director, Physicians, Digital Advisor. Coding Staffs",
                  status: TaskStatus.NotStarted
                }
            ]
        },
        {
            description: "Refine the treatment modules and theirs relations to the drone controls.",
            activities: [
                { 
                  description: "Drone Controls regarding the treatment of young infants.",
                  expectedChanges: "The drone acts like an human with its sensors, devices, etc. to list the treatment.",
                  signsOfSuccess: "Every identified sensors or devices will be tracked or/and inventoried, software module will be commited to the Github project source, all data collected will be stored in a database.",
                  dataGenerated: "Drone's Controls check up list or file. Online Data Exchange DataBase Commit on GitHUB",
                  keyPersonnel: "AGIR Director, Physicians, Digital Advisor. Coding Staffs",
                  status: TaskStatus.NotStarted
                },
                { 
                  description: "Drone recording and updating data related to the modules and algorithms.",
                  expectedChanges: "Drone acts as an intelligent device to record and update data.",
                  signsOfSuccess: "Drone's Controls check up list or file. Online Data Exchange DataBase Commit on GitHUB.",
                  dataGenerated: "Online Data Exchange DataBase Commit on GitHUB",
                  keyPersonnel: "AGIR Director, Physicians, Digital Advisor. Coding Staffs",
                  status: TaskStatus.NotStarted
                }
            ]
        },
        {
            description: "Refine the consul mother and follow up modules and theirs requirements to the drone controls.",
            activities: [
                { 
                  description: "Drone Controls regarding the consult mother and follow up modules.",
                  expectedChanges: "The drone acts like an human with its sensors, devices, etc. to consul mother.",
                  signsOfSuccess: "Drone's Controls check up list or file.",
                  dataGenerated: "Online Data Exchange DataBase Commit on GitHUB",
                  keyPersonnel: "AGIR Director, Physicians, Digital Advisor. Coding Staffs",
                  status: TaskStatus.NotStarted
                },
                { 
                  description: "Drone recording and updating data related to the modules and algorithms.",
                  expectedChanges: "Drone acts as an intelligent device to record and update data.",
                  signsOfSuccess: "Drone's Controls check up list or file.",
                  dataGenerated: "Online Data Exchange DataBase Commit on GitHUB",
                  keyPersonnel: "AGIR Director, Physicians, Digital Advisor. Coding Staffs",
                  status: TaskStatus.NotStarted
                }
            ]
        },
        {
            description: "Validation and feedback.",
            activities: [
                { 
                  description: "User testing (Product and UX).",
                  expectedChanges: "20 Users Tests are conducted.",
                  signsOfSuccess: "Users are satisfying with the product at 80%.",
                  dataGenerated: "Poll results. Online Data Exchange DataBase",
                  keyPersonnel: "Physicians, key power users, Digital Advisor",
                  status: TaskStatus.NotStarted
                },
                { 
                  description: "User testing (UI).",
                  expectedChanges: "10 users in Lab Test and 10 real users for 10 health Centers are required to give feed back on the user interface.",
                  signsOfSuccess: "UI is answering the 80% of the feed backs.",
                  dataGenerated: "Online Data Exchange DataBase",
                  keyPersonnel: "User testing and coding staff",
                  status: TaskStatus.NotStarted
                }
            ]
        }
    ],
    deliverables: {
        frontend: "Menu of the drone Controls available.",
        backend: "Drone Controls modules uploaded."
    }
  }
];