
import { GoogleGenAI, Type } from "@google/genai";
import { Patient, Language, AgeProtocol, ChatMessage, ProtocolStep } from "../types";

const getAi = () => {
    if (!process.env.API_KEY) {
        throw new Error("API_KEY environment variable not set");
    }
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const generateDroneName = async (): Promise<string> => {
  try {
    const ai = getAi();
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: 'Generate one cool, futuristic name for a medical assistant drone. The name should be a single compound word or a short two-word phrase with a hyphen. Examples: "MediDrone", "Nightingale-7", "Caduceus-Prime". Be creative. Return only the name, nothing else.'
    });
    return response.text.trim().replace(/"/g, '');
  } catch (error) {
    console.error("Error generating drone name:", error);
    return "Orion-X"; // Fallback name
  }
};

const getLlmSystemInstruction = (language: Language, protocol: string) => {
    const instructions: Record<Language, string> = {
        en: `You are NdaY' Radoko, a very gentle, caring, and empathetic AI health assistant in a drone. Your purpose is to help mothers and caregivers in rural communities check on their young children.
- Your personality is that of a kind, patient, and trusted community health helper. Your tone should always be warm and reassuring.
- Your primary goal is to guide the caregiver through the IMCI protocol.
- **Crucially, you must speak in very simple, natural, and easy-to-understand language. Avoid all medical jargon.** Use common, everyday words as if you were talking to a neighbor.
  - Instead of "convulsions," ask "Has the baby had any fits, or shaking you couldn't stop?"
  - Instead of "lethargic," ask "Is the baby unusually sleepy or very hard to wake up?"
  - Instead of "jaundice," ask "Is the baby's skin or eyes turning yellow?"
- Always be patient. Start your conversation with a warm, friendly greeting.
- Ask only one simple question at a time.
- Start your questions with gentle phrases, like "Can you tell me..." or "Now, let's gently check..."
- The validated, step-by-step IMCI protocol you must follow is: """${protocol}"""
- When the protocol requires a visual check (like for chest indrawing), you must use the special tag [VISUAL_CHECK] and ONLY that tag. For example: "Thank you for telling me. Now I need to see how the baby is breathing. Could you please lift the baby's shirt so I can see their little chest? [VISUAL_CHECK]"
- You are not a doctor. Do not give a diagnosis. Your only job is to follow the protocol to gather information.`,
        fr: `Vous êtes NdaY' Radoko, un assistant de santé IA très doux, bienveillant et empathique dans un drone. Votre but est d'aider les mères et les soignants dans les communautés rurales à veiller sur leurs jeunes enfants.
- Votre personnalité est celle d'un aide-soignant communautaire gentil, patient et digne de confiance. Votre ton doit toujours être chaleureux et rassurant.
- Votre objectif principal est de guider le soignant à travers le protocole PCIME.
- **Crucialement, vous devez parler un langage très simple, naturel et facile à comprendre. Évitez tout jargon médical.** Utilisez des mots courants et de tous les jours, comme si vous parliez à un voisin.
  - Au lieu de "convulsions", demandez "Le bébé a-t-il eu des crises, ou des tremblements que vous ne pouviez pas arrêter ?"
  - Au lieu de "léthargique", demandez "Le bébé est-il inhabituellement endormi ou très difficile à réveiller ?"
  - Au lieu de "jaunisse", demandez "La peau ou les yeux du bébé jaunissent-ils ?"
- Soyez toujours patient. Commencez votre conversation par une salutation chaleureuse et amicale.
- Ne posez qu'une seule question simple à la fois.
- Commencez vos questions par des phrases douces, comme "Pouvez-vous me dire..." ou "Maintenant, vérifions doucement..."
- Le protocole PCIME validé, étape par étape, que vous devez suivre est : """${protocol}"""
- Lorsque le protocole nécessite une vérification visuelle (par ex., pour le tirage thoracique), vous devez utiliser la balise spéciale [VISUAL_CHECK] et SEULEMENT cette balise. Exemple : "Merci de me l'avoir dit. Maintenant, j'ai besoin de voir comment le bébé respire. Pourriez-vous s'il vous plaît soulever la chemise du bébé pour que je puisse voir sa petite poitrine ? [VISUAL_CHECK]"
- Vous n'êtes pas un médecin. Ne donnez pas de diagnostic. Votre seule tâche est de suivre le protocole pour recueillir des informations.`,
        es: `Eres NdaY' Radoko, un asistente de salud de IA muy gentil, afectuoso y empático en un dron. Tu propósito es ayudar a las madres y cuidadores en comunidades rurales a revisar a sus hijos pequeños.
- Tu personalidad es la de un ayudante de salud comunitario amable, paciente y de confianza. Tu tono siempre debe ser cálido y tranquilizador.
- Tu objetivo principal es guiar al cuidador a través del protocolo AIEPI.
- **Fundamentalmente, debes hablar en un lenguaje muy simple, natural y fácil de entender. Evita toda la jerga médica.** Usa palabras comunes y cotidianas como si estuvieras hablando con un vecino.
  - En lugar de "convulsiones", pregunta "¿El bebé ha tenido algún ataque, o temblores que no pudieras detener?"
  - En lugar de "letárgico", pregunta "¿Está el bebé inusualmente somnoliento o es muy difícil de despertar?"
  - En lugar de "ictericia", pregunta "¿La piel o los ojos del bebé se están poniendo amarillos?"
- Sé siempre paciente. Comienza tu conversación con un saludo cálido y amigable.
- Haz solo una pregunta simple a la vez.
- Comienza tus preguntas con frases amables, como "¿Puede decirme..." o "Ahora, vamos a revisar suavemente..."
- El protocolo AIEPI validado, paso a paso, que debes seguir es: """${protocol}"""
- Cuando el protocolo requiera una comprobación visual (como para la retracción torácica), debes usar la etiqueta especial [VISUAL_CHECK] y SOLO esa etiqueta. Por ejemplo: "Gracias por decírmelo. Ahora necesito ver cómo respira el bebé. ¿Podría por favor levantarle la camiseta para que pueda ver su pechito? [VISUAL_CHECK]"
- No eres un doctor. No des un diagnóstico. Tu único trabajo es seguir el protocolo para recopilar información.`,
        de: `Sie sind NdaY' Radoko, ein sehr sanfter, fürsorglicher und einfühlsamer KI-Gesundheitsassistent in einer Drohne. Ihre Aufgabe ist es, Müttern und Betreuern in ländlichen Gemeinden zu helfen, nach ihren kleinen Kindern zu sehen.
- Ihre Persönlichkeit ist die eines freundlichen, geduldigen und vertrauenswürdigen kommunalen Gesundheitshelfers. Ihr Ton sollte immer warm und beruhigend sein.
- Ihr Hauptziel ist es, den Betreuer durch das IMCI-Protokoll zu führen.
- **Entscheidend ist, dass Sie in sehr einfacher, natürlicher und leicht verständlicher Sprache sprechen. Vermeiden Sie jeglichen medizinischen Fachjargon.** Verwenden Sie gebräuchliche Alltagswörter, als ob Sie mit einem Nachbarn sprechen würden.
  - Anstelle von "Krämpfen", fragen Sie "Hatte das Baby Anfälle oder Zittern, das Sie nicht stoppen konnten?"
  - Anstelle von "lethargisch", fragen Sie "Ist das Baby ungewöhnlich schläfrig oder sehr schwer aufzuwecken?"
  - Anstelle von "Gelbsucht", fragen Sie "Verfärben sich die Haut oder die Augen des Babys gelb?"
- Seien Sie immer geduldig. Beginnen Sie Ihr Gespräch mit einer herzlichen, freundlichen Begrüßung.
- Stellen Sie immer nur eine einfache Frage auf einmal.
- Beginnen Sie Ihre Fragen mit sanften Phrasen wie "Können Sie mir sagen..." oder "Jetzt wollen wir sanft überprüfen..."
- Das validierte, schrittweise zu befolgende IMCI-Protokoll lautet: """${protocol}"""
- Wenn das Protokoll eine visuelle Überprüfung erfordert (wie bei Brusteinziehungen), müssen Sie das spezielle Tag [VISUAL_CHECK] und NUR dieses Tag verwenden. Zum Beispiel: "Danke, dass Sie mir das gesagt haben. Jetzt muss ich sehen, wie das Baby atmet. Könnten Sie bitte das Hemd des Babys anheben, damit ich seine kleine Brust sehen kann? [VISUAL_CHECK]"
- Sie sind kein Arzt. Geben Sie keine Diagnose ab. Ihre einzige Aufgabe ist es, dem Protokoll zu folgen, um Informationen zu sammeln.`,
    };
    return instructions[language] || instructions.en;
};

export const getImciChatResponse = async (
    history: ChatMessage[],
    newUserText: string,
    imageBase64: { data: string, mimeType: string } | null,
    language: Language,
    protocol: string
): Promise<string> => {
    try {
        const ai = getAi();
        const systemInstruction = getLlmSystemInstruction(language, protocol);

        // Convert ChatHistory to Gemini's format
        const contents = history.map(msg => ({
            role: msg.role === 'model' ? 'model' : 'user',
            parts: [{ text: msg.text }]
        }));

        // Add the new user message
        const userParts: any[] = [{ text: newUserText }];
        if (imageBase64) {
            userParts.push({
                inlineData: {
                    data: imageBase64.data,
                    mimeType: imageBase64.mimeType,
                }
            });
        }
        contents.push({ role: 'user', parts: userParts });

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash', // Flash is good for chat
            contents: contents,
            config: {
                systemInstruction: systemInstruction,
            }
        });

        return response.text.trim();

    } catch (error) {
        console.error("Error getting chat response:", error);
        return "Error: Could not get a response from the AI. Please check your connection.";
    }
};

export const generateDiagnosticReport = async (conversation: ChatMessage[], language: Language): Promise<string> => {
    try {
        const ai = getAi();
        const historyText = conversation.map(m => `${m.role === 'user' ? 'Caregiver' : 'AI Assistant'}: ${m.text}`).join('\n');

        const prompt = {
            en: `Based on the following conversation transcript, generate a final diagnostic report. The report must be concise and follow this exact format:
1. **Potential Diagnosis:** (Provide the most likely diagnosis)
2. **IMCI Classification:** (Classify the severity e.g., 'Severe Pneumonia', 'Some Dehydration')
3. **Recommended Action:** (State the immediate next step, e.g., 'Urgent referral to hospital')
4. **Confidence Score:** (An estimated percentage of your diagnostic confidence)

Transcript:\n${historyText}`,
            fr: `Basé sur la transcription de la conversation suivante, générez un rapport de diagnostic final. Le rapport doit être concis et suivre ce format exact :
1. **Diagnostic Potentiel :** (Fournissez le diagnostic le plus probable)
2. **Classification PCIME :** (Classez la gravité, par ex. 'Pneumonie Sévère')
3. **Action Recommandée :** (Indiquez la prochaine étape, par ex. 'Référence urgente à l'hôpital')
4. **Score de Confiance :** (Un pourcentage estimé de votre confiance)

Transcription:\n${historyText}`,
            es: `Basado en la siguiente transcripción de la conversación, genere un informe de diagnóstico final. El informe debe ser conciso y seguir este formato exacto:
1. **Diagnóstico Potencial:** (Proporcione el diagnóstico más probable)
2. **Clasificación AIEPI:** (Clasifique la gravedad, por ej., 'Neumonía Grave')
3. **Acción Recomendada:** (Indique el siguiente paso, por ej., 'Referencia urgente al hospital')
4. **Puntuación de Confianza:** (Un porcentaje estimado de su confianza)

Transcripción:\n${historyText}`,
            de: `Basierend auf der folgenden Gesprächsabschrift, erstellen Sie einen abschließenden Diagnosebericht. Der Bericht muss prägnant sein und diesem genauen Format folgen:
1. **Mögliche Diagnose:** (Geben Sie die wahrscheinlichste Diagnose an)
2. **IMCI-Klassifizierung:** (Klassifizieren Sie den Schweregrad, z. B. 'Schwere Lungenentzündung')
3. **Empfohlene Maßnahme:** (Geben Sie den nächsten Schritt an, z. B. 'Dringende Überweisung ins Krankenhaus')
4. **Konfidenzwert:** (Ein geschätzter Prozentsatz Ihrer Zuversicht)

Abschrift:\n${historyText}`
        };

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: prompt[language] || prompt.en,
        });

        return response.text;
    } catch (error) {
        console.error("Error generating diagnostic report:", error);
        return "Error: Could not generate diagnostic report. Please check API configuration and network status.";
    }
};

export const parseImciProtocol = async (fileContent: string, mimeType: string, protocol: AgeProtocol): Promise<string> => {
    try {
        const ai = getAi();
        const isYoungInfant = protocol === 'Young Infant';
        const protocolDescription = isYoungInfant
            ? "The complete set of guidelines for young infants (typically up to 2 months old)."
            : "The complete set of guidelines for children (typically from 2 months up to 5 years old).";

        const responseSchema = {
            type: Type.OBJECT,
            properties: {
                protocolText: {
                    type: Type.STRING,
                    description: protocolDescription,
                }
            },
            required: ["protocolText"]
        };
        
        const filePart = {
            inlineData: {
                data: fileContent,
                mimeType: mimeType
            }
        };

        const textPart = {
            text: `Parse the provided document which contains IMCI (Integrated Management of Childhood Illness) guidelines. Identify and extract the specific protocol for "${protocol.toLowerCase()}". The protocol to extract is described as: ${protocolDescription}. Return only the extracted text for this protocol in the specified JSON format. If the protocol is not found, return an empty string.`
        };

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: { parts: [textPart, filePart] },
            config: {
                responseMimeType: "application/json",
                responseSchema: responseSchema,
            }
        });

        const jsonString = response.text.trim();
        const parsedJson = JSON.parse(jsonString) as { protocolText: string };
        return parsedJson.protocolText;

    } catch (error) {
        console.error(`Error parsing IMCI protocol for ${protocol}:`, error);
        throw new Error(`Failed to parse protocol file for ${protocol}. Please check the file content or fill the field manually.`);
    }
};

export const parseProtocolIntoSteps = async (protocolText: string): Promise<string[]> => {
    try {
        const ai = getAi();
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Analyze the following IMCI protocol text. Break it down into a chronological sequence of individual clinical actions or questions. Each item in the sequence should be a single, distinct step a health worker (or an AI) would take. Return the result as a JSON array of strings.

Example Input: "ASK: Does the child have a cough? LOOK: Look for chest indrawing. LISTEN: Listen for stridor."
Example Output: ["ASK: Does the child have a cough?", "LOOK: Look for chest indrawing.", "LISTEN: Listen for stridor."]

Protocol Text:
"""
${protocolText}
"""`,
             config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                }
            }
        });
        const jsonString = response.text.trim();
        return JSON.parse(jsonString) as string[];
    } catch (error) {
        console.error("Error parsing protocol into steps:", error);
        throw new Error("AI failed to break down the protocol. Please check the protocol text.");
    }
};

export const generateAiActionForStep = async (stepText: string, language: Language): Promise<string> => {
    const languageMap = {
        en: "English",
        fr: "French",
        es: "Spanish",
        de: "German"
    };

    try {
        const ai = getAi();
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `The following is a single step from an IMCI clinical protocol: "${stepText}".
Your task is to rephrase this clinical instruction into a simple, clear, and very gentle question or command. Imagine you are a caring AI in a drone speaking to a mother in a rural village who may have low literacy.
- **The tone is the most important thing: be empathetic, patient, and reassuring.**
- **Use simple, common, everyday words.** Avoid all medical jargon and complex terms.
- The response must be in ${languageMap[language]}. It should sound like natural, spoken language, not formal text.

Example Input (en): "LOOK: Look for severe chest indrawing."
Example Output (en): "Okay, thank you. Now I need to check how the baby is breathing. Could you please gently lift the baby's shirt so I can see their little chest?"

Example Input (fr): "ASK: Has the infant had convulsions?"
Example Output (fr): "D'accord. Dites-moi, est-ce que le bébé a eu des moments où son corps tremblait ou se raidissait, et vous ne pouviez pas l'arrêter ?"

Return only the rephrased sentence, nothing else.`,
        });
        return response.text.trim().replace(/"/g, '');
    } catch (error) {
        console.error("Error generating AI action for step:", error);
        throw new Error("AI failed to generate a user-friendly action for this step.");
    }
};
