import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { Drone, DroneStatus, Patient, PatientStatus, Country, AgeProtocol, PlanQuarter, TaskStatus, ProtocolStep, UserRole } from './types';
import { INITIAL_DRONES, INITIAL_PATIENTS, INITIAL_COUNTRIES, INITIAL_IMPLEMENTATION_PLAN } from './constants';
import { generateDiagnosticReport } from './services/geminiService';
import { useTranslations } from './LanguageContext';

import Navbar, { Page } from './components/Navbar';
import HomePage from './pages/HomePage';
import DronesPage from './pages/DronesPage';
import PatientsPage from './pages/PatientsPage';
import AdminPage from './pages/AdminPage';

import AddDroneModal from './components/AddDroneModal';
import DiagnosticReportModal from './components/DiagnosticReportModal';
import AssignDroneModal from './components/AssignDroneModal';
import AddPatientModal from './components/AddPatientModal';
import ActivityLogModal from './components/ActivityLogModal';
import PromConfigurationModal from './components/PromConfigurationModal';
import ImplementationPlanModal from './components/ImplementationPlanModal';
import LiveDiagnosisModal from './components/LiveDiagnosisModal';
import PromTrainingModal from './components/PromTrainingModal';
import DecommissionDroneModal from './components/DecommissionDroneModal';
import AccessDeniedPage from './components/AccessDeniedPage';


const App: React.FC = () => {
  const [drones, setDrones] = useState<Drone[]>(() => {
    try {
      const savedDrones = localStorage.getItem('drones');
      return savedDrones ? JSON.parse(savedDrones) : INITIAL_DRONES;
    } catch (error) {
      console.error("Failed to parse drones from localStorage", error);
      return INITIAL_DRONES;
    }
  });

  const [patients, setPatients] = useState<Patient[]>(() => {
    try {
      const savedPatients = localStorage.getItem('patients');
      return savedPatients ? JSON.parse(savedPatients) : INITIAL_PATIENTS;
    } catch (error) {
      console.error("Failed to parse patients from localStorage", error);
      return INITIAL_PATIENTS;
    }
  });

  const [countries, setCountries] = useState<Country[]>(() => {
    try {
      const savedCountries = localStorage.getItem('countries');
      return savedCountries ? JSON.parse(savedCountries) : INITIAL_COUNTRIES;
    } catch (error) {
      console.error("Failed to parse countries from localStorage", error);
      return INITIAL_COUNTRIES;
    }
  });
  
  const [implementationPlan, setImplementationPlan] = useState<PlanQuarter[]>(() => {
    try {
        const savedPlan = localStorage.getItem('implementationPlan');
        return savedPlan ? JSON.parse(savedPlan) : INITIAL_IMPLEMENTATION_PLAN;
    } catch (error) {
        console.error("Failed to parse plan from localStorage", error);
        return INITIAL_IMPLEMENTATION_PLAN;
    }
  });


  useEffect(() => {
    localStorage.setItem('drones', JSON.stringify(drones));
  }, [drones]);

  useEffect(() => {
    localStorage.setItem('patients', JSON.stringify(patients));
  }, [patients]);

  useEffect(() => {
    localStorage.setItem('countries', JSON.stringify(countries));
  }, [countries]);

  useEffect(() => {
    localStorage.setItem('implementationPlan', JSON.stringify(implementationPlan));
  }, [implementationPlan]);

  
  const [activeCountryId, setActiveCountryId] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [currentUserRole, setCurrentUserRole] = useState<UserRole>('Admin Global');
  
  // Modal States
  const [isAddModalOpen, setAddModalOpen] = useState(false);
  const [isAddPatientModalOpen, setAddPatientModalOpen] = useState(false);
  const [isReportModalOpen, setReportModalOpen] = useState(false);
  const [isAssignModalOpen, setAssignModalOpen] = useState(false);
  const [isActivityLogModalOpen, setActivityLogModalOpen] = useState(false);
  const [isPromConfigModalOpen, setPromConfigModalOpen] = useState(false);
  const [isPlanModalOpen, setPlanModalOpen] = useState(false);
  const [isLiveDiagnosisModalOpen, setLiveDiagnosisModalOpen] = useState(false);
  const [isPromTrainingModalOpen, setPromTrainingModalOpen] = useState(false);
  const [isDecommissionModalOpen, setDecommissionModalOpen] = useState(false);
  
  // Selected items for modals
  const [selectedDrone, setSelectedDrone] = useState<Drone | null>(null);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [patientForAssignment, setPatientForAssignment] = useState<Patient | null>(null);
  const [droneForPromConfig, setDroneForPromConfig] = useState<Drone | null>(null);
  const [droneForDecommission, setDroneForDecommission] = useState<Drone | null>(null);
  const [countryForImplementation, setCountryForImplementation] = useState<string | null>(null);
  const [countryForPromTraining, setCountryForPromTraining] = useState<Country | null>(null);
  const [activeDiagnosisSession, setActiveDiagnosisSession] = useState<{ patientId: string; droneId: string } | null>(null);

  const [diagnosticReport, setDiagnosticReport] = useState<string | null>(null);
  const [isLoadingReport, setIsLoadingReport] = useState(false);

  const { language, setLanguage } = useTranslations();

  const handleSelectCountry = useCallback((countryId: string | null) => {
    setActiveCountryId(countryId);
    if (countryId) {
        const country = countries.find(c => c.id === countryId);
        if(country) {
            setLanguage(country.localLanguage);
        }
    }
  }, [countries, setLanguage]);

  const updateDrone = useCallback((id: string, updates: Partial<Omit<Drone, 'id'>>, newActivity?: { event: string; details?: string }) => {
    setDrones(prevDrones =>
        prevDrones.map(d => {
            if (d.id !== id) return d;
            const newLog = newActivity
                ? [{ timestamp: new Date().toISOString(), ...newActivity }, ...d.activityLog]
                : d.activityLog;
            return { ...d, ...updates, activityLog: newLog };
        })
    );
  }, []);
  
  const handleOpenPromConfigModal = useCallback((droneId: string) => {
    const drone = drones.find(d => d.id === droneId);
    if (drone) {
      setDroneForPromConfig(drone);
      setPromConfigModalOpen(true);
    }
  }, [drones]);

  const handleStartPromProcess = useCallback((id: string, ageProtocol: AgeProtocol) => {
    setPromConfigModalOpen(false);
    const drone = drones.find(d => d.id === id);
    if (!drone) return;
    
    const countryName = countries.find(c => c.id === drone.countryId)?.name || 'Unknown';
    const eventDetails = `Country: ${countryName}, Protocol: ${ageProtocol}`;
    const isUpdate = drone.status !== DroneStatus.Pending;
    const eventName = isUpdate ? 'IMCI PROM Update Initiated' : 'PROM Initiated';
    
    updateDrone(id, { status: DroneStatus.InProgress }, { event: eventName, details: eventDetails });
    
    setTimeout(() => {
      const success = Math.random() > 0.2; // 80% success rate
      if (success) {
        const newAccuracy = 95 + Math.random() * 4.9; // 95.0% to 99.9%
        updateDrone(id, { status: DroneStatus.Success, accuracy: newAccuracy, ageProtocol }, { event: 'PROM Successful', details: eventDetails });
      } else {
        updateDrone(id, { status: DroneStatus.Failed }, { event: 'PROM Failed', details: eventDetails });
      }
    }, 4000 + Math.random() * 2000);
  }, [updateDrone, countries, drones]);

  const handleSelfDiagnostics = useCallback(async (id: string) => {
    const drone = drones.find(d => d.id === id);
    if (!drone) return;

    updateDrone(id, {}, { event: 'Self-Diagnostic Run' });

    setSelectedDrone(drone);
    setSelectedPatient(null);
    setReportModalOpen(true);
    setIsLoadingReport(true);
    setDiagnosticReport(null);

    const report = `Self-Diagnostic Complete.
1. **System Status:** All systems nominal.
2. **AI Core:** Healthy.
3. **Accuracy Calibration:** ${drone.accuracy?.toFixed(1)}%
4. **Next Action:** Ready for patient assignment.`;
    
    setTimeout(() => {
        setDiagnosticReport(report);
        setIsLoadingReport(false);
    }, 3800)
  }, [drones, updateDrone]);

  const handleDecommission = useCallback((id: string) => {
    const droneToDecommission = drones.find(d => d.id === id);
    if (droneToDecommission) {
        setDroneForDecommission(droneToDecommission);
        setDecommissionModalOpen(true);
    }
  }, [drones]);

  const handleConfirmDecommission = useCallback((id: string, reason: string, actions: string) => {
    const details = `Reason: ${reason}. Recommended Actions: ${actions || 'N/A'}`;
    updateDrone(
      id,
      { status: DroneStatus.Decommissioned, decommissionReason: reason, recommendedActions: actions },
      { event: 'Decommissioned', details }
    );
    setDecommissionModalOpen(false);
    setDroneForDecommission(null);
  }, [updateDrone]);

  const handleAddDrone = (name: string) => {
    if (!activeCountryId) return;
    const newIdNumber = drones.length + 1;
    const newDrone: Drone = {
      id: `IMCI-D-${String(newIdNumber).padStart(3, '0')}`,
      name,
      status: DroneStatus.Pending,
      accuracy: null,
      activityLog: [{ timestamp: new Date().toISOString(), event: 'Registered to Fleet' }],
      countryId: activeCountryId,
      ageProtocol: null,
    };
    setDrones(prevDrones => [newDrone, ...prevDrones]);
  };

  const handleAddPatient = ({ name, age, symptoms }: { name: string; age: string; symptoms: string[] }) => {
    if (!activeCountryId) return;
    const newIdNumber = patients.length + 1;
    const newPatient: Patient = {
        id: `P-${String(newIdNumber).padStart(3, '0')}`,
        name,
        age,
        symptoms,
        status: PatientStatus.AwaitingDiagnosis,
        assignedDroneId: null,
        diagnosticReport: null,
        countryId: activeCountryId,
    };
    setPatients(prevPatients => [newPatient, ...prevPatients]);
  };

    const handleAddCountry = (country: Omit<Country, 'id'|'isImplemented'>) => {
        const newCountry: Country = {
            id: country.name.toLowerCase().replace(/\s+/g, '-'),
            isImplemented: false,
            ...country,
        };
        setCountries(prev => [...prev, newCountry]);
    };
    
    const handleToggleCountryImplementation = (countryId: string) => {
        const country = countries.find(c => c.id === countryId);
        if (!country) return;

        if (!country.isImplemented) {
            setCountryForImplementation(countryId);
            setPlanModalOpen(true);
        } else {
            setCountries(prev => prev.map(c => c.id === countryId ? {...c, isImplemented: false} : c));
        }
    };

    const handleConfirmImplementation = () => {
        if (countryForImplementation) {
            setCountries(prev => prev.map(c => c.id === countryForImplementation ? {...c, isImplemented: true} : c));
        }
        setPlanModalOpen(false);
        setCountryForImplementation(null);
    };

    const handleUpdateActivityStatus = useCallback((quarterName: string, milestoneDesc: string, activityDesc: string, status: TaskStatus) => {
        setImplementationPlan(prevPlan => {
            const newPlan = JSON.parse(JSON.stringify(prevPlan)); // Deep copy for safety
            const quarter = newPlan.find((q: PlanQuarter) => q.name === quarterName);
            if (quarter) {
                const milestone = quarter.milestones.find((m: any) => m.description === milestoneDesc);
                if (milestone) {
                    const activity = milestone.activities.find((a: any) => a.description === activityDesc);
                    if (activity) {
                        activity.status = status;
                    }
                }
            }
            return newPlan;
        });
    }, []);

    const handleStartPromTraining = useCallback((countryId: string) => {
        const country = countries.find(c => c.id === countryId);
        if (country) {
            setCountryForPromTraining(country);
            setPromTrainingModalOpen(true);
        }
    }, [countries]);

    const handleSaveValidatedProtocol = useCallback((countryId: string, protocolType: AgeProtocol, steps: ProtocolStep[]) => {
        setCountries(prev => prev.map(c => {
            if (c.id === countryId) {
                if (protocolType === 'Young Infant') {
                    return { ...c, youngInfantProtocolSteps: steps };
                } else {
                    return { ...c, childProtocolSteps: steps };
                }
            }
            return c;
        }));
        setPromTrainingModalOpen(false);
        setCountryForPromTraining(null);
    }, []);


  const handleOpenAssignModal = useCallback((patient: Patient) => {
    setPatientForAssignment(patient);
    setAssignModalOpen(true);
  }, []);
  
  const handleStartLiveDiagnosis = useCallback((droneId: string) => {
      const patient = patientForAssignment;
      if (!patient) return;

      setAssignModalOpen(false);
      
      setPatients(prev => prev.map(p => p.id === patient.id ? {...p, status: PatientStatus.DiagnosisInProgress} : p));
      updateDrone(droneId, { status: DroneStatus.Diagnosing, assignedPatientId: patient.id }, { event: `Live Diagnosis Started`, details: `Patient: ${patient.name} (${patient.id})` });
      
      setActiveDiagnosisSession({ patientId: patient.id, droneId });
      setLiveDiagnosisModalOpen(true);
  }, [patientForAssignment, updateDrone]);

  const handleConcludeDiagnosis = useCallback(async (conversationHistory: any[]) => {
    if (!activeDiagnosisSession) return;
    const { patientId, droneId } = activeDiagnosisSession;

    setLiveDiagnosisModalOpen(false);
    
    // Show report modal with loading state
    const patient = patients.find(p => p.id === patientId);
    const drone = drones.find(d => d.id === droneId);
    setSelectedPatient(patient || null);
    setSelectedDrone(drone || null);
    setReportModalOpen(true);
    setIsLoadingReport(true);
    setDiagnosticReport(null);

    const report = await generateDiagnosticReport(conversationHistory, language);

    const accuracyChange = (Math.random() - 0.5) * 0.2;
    let newAccuracy = (drone?.accuracy || 98) + accuracyChange;
    newAccuracy = Math.max(95, Math.min(99.9, newAccuracy));

    setPatients(prev => prev.map(p => p.id === patientId ? {
      ...p, 
      status: PatientStatus.Diagnosed, 
      diagnosticReport: report,
      assignedDroneId: droneId,
      conversationHistory,
    } : p));

    updateDrone(droneId, {
      status: DroneStatus.Active, 
      lastDiagnostic: report, 
      accuracy: newAccuracy,
      assignedPatientId: undefined
    }, { event: 'Diagnosis Complete', details: `Patient: ${patient?.name} (${patient?.id})` });

    setDiagnosticReport(report);
    setIsLoadingReport(false);
    setActiveDiagnosisSession(null);
    setPatientForAssignment(null);
  }, [activeDiagnosisSession, drones, patients, updateDrone, language]);


  const handleViewPatientReport = useCallback((patient: Patient) => {
      const drone = drones.find(d => d.id === patient.assignedDroneId);
      setSelectedPatient(patient);
      setSelectedDrone(drone || null);
      setDiagnosticReport(patient.diagnosticReport);
      setReportModalOpen(true);
      setIsLoadingReport(false);
  }, [drones]);

  const handleViewActivityLog = useCallback((id: string) => {
    const drone = drones.find(d => d.id === id);
    if(drone) {
        setSelectedDrone(drone);
        setActivityLogModalOpen(true);
    }
  }, [drones]);

  const filteredDrones = useMemo(() => drones.filter(d => d.countryId === activeCountryId), [drones, activeCountryId]);
  const filteredPatients = useMemo(() => patients.filter(p => p.countryId === activeCountryId), [patients, activeCountryId]);
  const availableDrones = useMemo(() => 
    filteredDrones.filter(d => (d.status === DroneStatus.Active || d.status === DroneStatus.Success) && !d.assignedPatientId), 
  [filteredDrones]);
  
  const handleSelectCountryAndNavigate = useCallback((countryId: string) => {
    handleSelectCountry(countryId);
    setCurrentPage('drones');
  }, [handleSelectCountry]);

  const renderPage = () => {
    switch (currentPage) {
        case 'home':
            return <HomePage 
                countries={countries}
                onSelectCountryAndNavigate={handleSelectCountryAndNavigate}
            />;
        case 'patients':
            return <PatientsPage 
                patients={filteredPatients}
                activeCountryId={activeCountryId}
                onAddPatientClick={() => setAddPatientModalOpen(true)}
                onAssignDrone={handleOpenAssignModal}
                onViewReport={handleViewPatientReport}
            />;
        case 'drones':
            return <DronesPage
                drones={filteredDrones}
                countries={countries}
                activeCountryId={activeCountryId}
                onAddDroneClick={() => setAddModalOpen(true)}
                onConfigureProm={handleOpenPromConfigModal}
                onRunDiagnostics={handleSelfDiagnostics}
                onDecommission={handleDecommission}
                onViewActivityLog={handleViewActivityLog}
            />;
        case 'admin':
            return currentUserRole === 'Admin Global' ? (
                <AdminPage 
                    countries={countries}
                    onAddCountry={handleAddCountry}
                    onToggleImplementation={handleToggleCountryImplementation}
                    onStartPromTraining={handleStartPromTraining}
                    implementationPlan={implementationPlan}
                    onUpdateActivityStatus={handleUpdateActivityStatus}
                />
            ) : (
                <AccessDeniedPage onGoHome={() => setCurrentPage('home')} />
            );
        default:
            return <HomePage countries={countries} onSelectCountryAndNavigate={handleSelectCountryAndNavigate} />;
    }
  };
  
  const activeDiagnosisPatient = useMemo(() => patients.find(p => p.id === activeDiagnosisSession?.patientId), [patients, activeDiagnosisSession]);
  const activeDiagnosisDrone = useMemo(() => drones.find(d => d.id === activeDiagnosisSession?.droneId), [drones, activeDiagnosisSession]);
  const activeDiagnosisCountry = useMemo(() => countries.find(c => c.id === activeDiagnosisDrone?.countryId), [countries, activeDiagnosisDrone]);


  return (
    <div className="min-h-screen bg-brand-background flex">
      <Navbar 
        currentPage={currentPage} 
        setCurrentPage={setCurrentPage}
        countries={countries}
        activeCountryId={activeCountryId}
        onSelectCountry={handleSelectCountry}
        currentUserRole={currentUserRole}
        setCurrentUserRole={setCurrentUserRole}
      />
      <main className="flex-1 overflow-y-auto">
        <div className="container mx-auto p-4 md:p-8">
            {renderPage()}
        </div>
      </main>

      <AddDroneModal
        isOpen={isAddModalOpen}
        onClose={() => setAddModalOpen(false)}
        onAddDrone={handleAddDrone}
      />
      <AddPatientModal
        isOpen={isAddPatientModalOpen}
        onClose={() => setAddPatientModalOpen(false)}
        onAddPatient={handleAddPatient}
      />
      <DiagnosticReportModal
        isOpen={isReportModalOpen}
        onClose={() => setReportModalOpen(false)}
        drone={selectedDrone}
        patient={selectedPatient}
        report={diagnosticReport}
        isLoading={isLoadingReport}
      />
      <AssignDroneModal 
        isOpen={isAssignModalOpen}
        onClose={() => setAssignModalOpen(false)}
        patient={patientForAssignment}
        availableDrones={availableDrones}
        onAssign={handleStartLiveDiagnosis}
      />
      <ActivityLogModal
        isOpen={isActivityLogModalOpen}
        onClose={() => setActivityLogModalOpen(false)}
        drone={selectedDrone}
      />
      <PromConfigurationModal
        isOpen={isPromConfigModalOpen}
        onClose={() => setPromConfigModalOpen(false)}
        drone={droneForPromConfig}
        countries={countries}
        onConfirm={handleStartPromProcess}
      />
      <ImplementationPlanModal
        isOpen={isPlanModalOpen}
        onClose={() => { setPlanModalOpen(false); setCountryForImplementation(null); }}
        onConfirm={handleConfirmImplementation}
      />
       {countryForPromTraining && (
          <PromTrainingModal
            isOpen={isPromTrainingModalOpen}
            onClose={() => { setPromTrainingModalOpen(false); setCountryForPromTraining(null); }}
            onSave={handleSaveValidatedProtocol}
            country={countryForPromTraining}
          />
       )}
      {activeDiagnosisPatient && activeDiagnosisDrone && activeDiagnosisCountry && (
        <LiveDiagnosisModal
          isOpen={isLiveDiagnosisModalOpen}
          onConclude={handleConcludeDiagnosis}
          patient={activeDiagnosisPatient}
          drone={activeDiagnosisDrone}
          country={activeDiagnosisCountry}
        />
      )}
      <DecommissionDroneModal
        isOpen={isDecommissionModalOpen}
        onClose={() => setDecommissionModalOpen(false)}
        drone={droneForDecommission}
        onConfirm={handleConfirmDecommission}
       />
    </div>
  );
};

export default App;